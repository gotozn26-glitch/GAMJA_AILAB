import * as esbuild from "esbuild";
import { mkdirSync, readFileSync, writeFileSync } from "fs";
import { dirname, join } from "path";
import { fileURLToPath } from "url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const watch = process.argv.includes("--watch");

const copyUiHtml = () => {
  mkdirSync(join(__dirname, "dist"), { recursive: true });
  const htmlTemplate = readFileSync(join(__dirname, "src/ui/ui.html"), "utf8");
  const uiScript = readFileSync(join(__dirname, "dist/ui.js"), "utf8");
  const html = htmlTemplate.replace(
    "<!-- UI_SCRIPT -->",
    `<script>${uiScript}</script>`
  );
  writeFileSync(join(__dirname, "dist/ui.html"), html);
};

const ctx = await esbuild.context({
  entryPoints: {
    code: join(__dirname, "src/code.ts"),
    ui: join(__dirname, "src/ui/ui.ts"),
  },
  bundle: true,
  outfile: undefined,
  outdir: join(__dirname, "dist"),
  target: "es2017",
  format: "iife",
  platform: "browser",
  logLevel: "info",
});

if (watch) {
  await ctx.watch();
  copyUiHtml();
  console.log("Watching...");
} else {
  await ctx.rebuild();
  await ctx.dispose();
  copyUiHtml();
  console.log("Build complete.");
}
