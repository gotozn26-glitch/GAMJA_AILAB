# Session to HTML — Figma Plugin

피그마 **현재 페이지(세션) 전체**를 HTML/CSS와 `image/` 자산 폴더로 변환하는 플러그인입니다.

## 기능

- **현재 페이지 전체** — 페이지에 있는 모든 최상위 레이어를 한 HTML 문서로보냄
- **선택 레이어만** — 선택한 프레임/그룹만 변환
- **모든 페이지** — 파일 내 모든 페이지의 레이어를 하나의 HTML로보냄
- 텍스트, 색상, 모서리, 그림자, Auto Layout(flexbox) 반영
- 사각형, 원형, 기본 라인 도형은 가능한 범위에서 HTML/CSS로 렌더링
- 이미지 fill, 벡터, 폴리곤/스타, 마스크가 포함된 블록은 PNG 자산으로 추출
- **CSS 출력 방식 선택**
  - **인라인** — 모든 스타일이 HTML `style` 속성에 포함
  - **파일 분리** — `index.html` + `styles.css` (같은 폴더에 두 파일 저장)
- **이미지 출력 방식 선택**
  - **`image/` 폴더 분리** — 서버 업로드용 기본값
  - **HTML 임베드** — 단일 파일 미리보기용
- HTML / CSS 각각 클립보드 복사 및 다운로드
- **ZIP으로 한번에 받기** — HTML(+ CSS 분리 시 `styles.css`, `image/`)을 하나의 ZIP으로 다운로드

## 설치 및 실행

```bash
npm install
npm run build
```

1. Figma Desktop에서 **Plugins → Development → Import plugin from manifest…**
2. 이 프로젝트의 `manifest.json` 선택
3. **Plugins → Development → Session to HTML** 실행

개발 중에는 `npm run watch`로 파일 변경 시 자동 빌드할 수 있습니다.

## 사용법

1.보낼 페이지를 연다.
2. 플러그인을 실행한다.
3. 범위와 옵션을 선택한 뒤 **HTML보내기**를 클릭한다.
4. **ZIP으로 한번에 받기**로 결과를 저장한다.

CSS 분리 모드일 때는 `styles.css`와 HTML을 **같은 폴더**에 두어야 스타일이 적용됩니다.
이미지 분리 모드일 때는 HTML 기준 상대경로 `image/...`를 사용하므로 `image/` 폴더도 함께 업로드해야 합니다.

## 한계

- 피그마와 100% 동일한 픽셀 재현은 어렵습니다(복합 블렌드, 특수 폰트, 일부 벡터 효과 등).
- 컴포넌트 인스턴스 오버라이드는 기본 구조 위주로 변환됩니다.
- 대용량 페이지는 PNG 자산이 많을수록 변환과 ZIP 생성이 오래 걸릴 수 있습니다.

## 프로젝트 구조

```
src/
  code.ts              # 플러그인 메인 (Figma 샌드박스)
  export/
    htmlExporter.ts    # 노드 → HTML 변환
    styles.ts          # CSS 유틸
  ui/
    ui.html / ui.ts    # 플러그인 UI
manifest.json
```
