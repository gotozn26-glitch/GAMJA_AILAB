import { CssBuilder } from "./cssBuilder";
import {
  cornerRadius,
  cssObject,
  effectsToCss,
  escapeHtml,
  fillToCss,
  getStrokeDescriptor,
  sanitizeFileSegment,
  strokeToCss,
} from "./styles";
import type { ExportAsset, ExportOptions, ExportResult } from "./types";

const CONTAINER_TYPES = new Set([
  "FRAME",
  "GROUP",
  "COMPONENT",
  "INSTANCE",
  "SECTION",
  "COMPONENT_SET",
]);

const ALWAYS_RASTER_TYPES = new Set([
  "VECTOR",
  "BOOLEAN_OPERATION",
  "POLYGON",
  "STAR",
]);

const LIKELY_HTML_SAFE_FONT_FAMILIES = new Set([
  "Arial",
  "Arial Black",
  "Apple SD Gothic Neo",
  "Courier New",
  "Georgia",
  "Helvetica",
  "Helvetica Neue",
  "Impact",
  "Inter",
  "Malgun Gothic",
  "Noto Sans",
  "Noto Sans CJK KR",
  "Noto Sans KR",
  "Noto Serif KR",
  "Nanum Gothic",
  "Pretendard",
  "SF Pro",
  "SF Pro Display",
  "SF Pro Text",
  "Tahoma",
  "Times New Roman",
  "Trebuchet MS",
  "Verdana",
  "맑은 고딕",
]);

const CSS_FILE_NAME = "styles.css";
const IMAGE_DIR_NAME = "image";

type Origin = { x: number; y: number };
type Bounds = Origin & { width: number; height: number };

export class HtmlExporter {
  private assetCache = new Map<string, string>();
  private assetContentCache = new Map<string, string>();
  private assets: ExportAsset[] = [];
  private nodeCount = 0;
  private cssBuilder: CssBuilder | null = null;
  private nodeClassMap = new Map<string, string>();
  private cssMode: ExportOptions["cssMode"] = "inline";
  private assetMode: ExportOptions["assetMode"] = "external";
  private assetIndex = 0;

  async export(nodes: readonly SceneNode[], options: ExportOptions): Promise<ExportResult> {
    this.assetCache.clear();
    this.assetContentCache.clear();
    this.assets = [];
    this.assetIndex = 0;
    this.nodeCount = 0;
    this.nodeClassMap.clear();
    this.cssMode = options.cssMode;
    this.assetMode = options.assetMode;
    this.cssBuilder = options.cssMode === "external" ? new CssBuilder() : null;

    const visibleNodes = nodes.filter((node) => options.includeHidden || node.visible);
    if (visibleNodes.length === 0) {
      throw new Error("보낼 노드가 없습니다.");
    }

    const bounds = this.getBounds(visibleNodes);
    const bodyParts: string[] = [];

    for (const node of visibleNodes) {
      const html = await this.nodeToHtml(node, bounds, options, true);
      if (html) bodyParts.push(html);
    }

    const pageName =
      nodes[0] && nodes[0].parent && nodes[0].parent.type === "PAGE"
        ? (nodes[0].parent as PageNode).name
        : figma.currentPage.name;

    const rootStyles = {
      width: `${bounds.width}px`,
      height: `${bounds.height}px`,
    };

    let rootAttrs = "";
    if (this.cssMode === "external") {
      this.cssBuilder!.add(".figma-export-root", rootStyles);
      rootAttrs = ' class="figma-export-root"';
    } else {
      rootAttrs = ` class="figma-export-root" style="${escapeHtml(cssObject(rootStyles))}"`;
    }

    const css = this.cssMode === "external" ? this.cssBuilder!.build() : null;
    const html = this.wrapDocument(pageName, bodyParts.join("\n"), rootAttrs, css !== null);

    return {
      html,
      css,
      cssMode: this.cssMode,
      assetMode: this.assetMode,
      assets: this.assets,
      width: bounds.width,
      height: bounds.height,
      nodeCount: this.nodeCount,
      pageName,
    };
  }

  private wrapDocument(pageName: string, body: string, rootAttrs: string, externalCss: boolean): string {
    const stylesheet = externalCss
      ? `  <link rel="stylesheet" href="${CSS_FILE_NAME}" />`
      : `  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      min-height: 100vh;
      background: #f5f5f5;
      display: flex;
      justify-content: center;
      padding: 24px;
      font-family: "Pretendard", system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    }
    .figma-export-root {
      position: relative;
      background: #fff;
      overflow: hidden;
      box-shadow: 0 4px 24px rgba(0,0,0,0.08);
    }
    img { display: block; max-width: 100%; }
    .figma-text { white-space: pre-wrap; word-break: break-word; }
  </style>`;

    return `<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${escapeHtml(pageName)} — Figma Export</title>
${stylesheet}
</head>
<body>
  <div${rootAttrs}>
${body}
  </div>
</body>
</html>`;
  }

  private getNodeClass(node: SceneNode): string {
    let cls = this.nodeClassMap.get(node.id);
    if (!cls) {
      cls = `fn-${this.nodeClassMap.size + 1}`;
      this.nodeClassMap.set(node.id, cls);
    }
    return cls;
  }

  private styleAttrs(node: SceneNode, styles: Record<string, string>, typeClass: string): string {
    const classes = [typeClass, this.getNodeClass(node)].filter(Boolean).join(" ");

    if (this.cssMode === "external") {
      this.cssBuilder!.add(`.${this.getNodeClass(node)}`, styles);
      return ` class="${classes}"`;
    }

    const inline = cssObject(styles);
    return inline ? ` class="${classes}" style="${escapeHtml(inline)}"` : ` class="${classes}"`;
  }

  private getBounds(nodes: readonly SceneNode[]): Bounds {
    let minX = Infinity;
    let minY = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;

    for (const node of nodes) {
      if (!("absoluteBoundingBox" in node) || !node.absoluteBoundingBox) continue;
      const b = node.absoluteBoundingBox;
      minX = Math.min(minX, b.x);
      minY = Math.min(minY, b.y);
      maxX = Math.max(maxX, b.x + b.width);
      maxY = Math.max(maxY, b.y + b.height);
    }

    if (!isFinite(minX)) {
      return { x: 0, y: 0, width: 100, height: 100 };
    }

    return {
      x: minX,
      y: minY,
      width: Math.ceil(maxX - minX),
      height: Math.ceil(maxY - minY),
    };
  }

  private getRelativeBox(node: SceneNode, origin: Origin): Bounds | null {
    if (!("absoluteBoundingBox" in node) || !node.absoluteBoundingBox) return null;
    const b = node.absoluteBoundingBox;
    return {
      left: b.x - origin.x,
      top: b.y - origin.y,
      width: b.width,
      height: b.height,
      x: b.x - origin.x,
      y: b.y - origin.y,
    } as Bounds;
  }

  private getAbsoluteOrigin(node: SceneNode): Origin | null {
    if (!("absoluteBoundingBox" in node) || !node.absoluteBoundingBox) return null;
    return {
      x: node.absoluteBoundingBox.x,
      y: node.absoluteBoundingBox.y,
    };
  }

  private parentUsesAutoLayout(node: SceneNode): boolean {
    const parent = node.parent;
    if (!parent || parent.type === "PAGE" || parent.type === "DOCUMENT") return false;
    return this.hasAutoLayout(parent as SceneNode);
  }

  private hasAutoLayout(node: SceneNode): node is FrameNode | ComponentNode | InstanceNode {
    return (
      (node.type === "FRAME" || node.type === "COMPONENT" || node.type === "INSTANCE") &&
      node.layoutMode !== "NONE"
    );
  }

  private hasMaskChild(node: SceneNode): boolean {
    if (!("children" in node)) return false;
    return node.children.some((child) => "isMask" in child && child.isMask);
  }

  private hasTextDescendant(node: SceneNode): boolean {
    if (
      node.type === "TEXT" ||
      node.type === "SHAPE_WITH_TEXT" ||
      node.type === "STICKY" ||
      node.type === "CODE_BLOCK"
    ) {
      return true;
    }

    if (!("children" in node)) return false;
    return node.children.some((child) => this.hasTextDescendant(child));
  }

  private layoutStyles(node: FrameNode | ComponentNode | InstanceNode): Record<string, string> {
    const styles: Record<string, string> = {
      display: "flex",
      flexDirection: node.layoutMode === "HORIZONTAL" ? "row" : "column",
    };

    const alignMap: Record<string, string> = {
      MIN: "flex-start",
      CENTER: "center",
      MAX: "flex-end",
      SPACE_BETWEEN: "space-between",
      BASELINE: "baseline",
    };

    styles.justifyContent = alignMap[node.primaryAxisAlignItems] || "flex-start";
    styles.alignItems = alignMap[node.counterAxisAlignItems] || "flex-start";

    if (node.itemSpacing > 0) {
      styles.gap = `${node.itemSpacing}px`;
    }

    const padding = [node.paddingTop, node.paddingRight, node.paddingBottom, node.paddingLeft];
    if (padding.some((value) => value > 0)) {
      styles.padding = padding.map((value) => `${value}px`).join(" ");
    }

    return styles;
  }

  private baseStyles(
    node: SceneNode,
    origin: Origin,
    useAbsolute: boolean,
    includeVisualStyles = true
  ): Record<string, string> {
    const box = this.getRelativeBox(node, origin);
    if (!box) return { display: "none" };

    const styles: Record<string, string> = {
      width: `${box.width}px`,
      height: `${box.height}px`,
      opacity: String("opacity" in node ? node.opacity : 1),
    };

    if (useAbsolute) {
      styles.position = "absolute";
      styles.left = `${box.x}px`;
      styles.top = `${box.y}px`;
    }

    if ("rotation" in node && node.rotation !== 0) {
      styles.transform = `rotate(${node.rotation}deg)`;
      styles.transformOrigin = "center";
    }

    if (includeVisualStyles) {
      if ("fills" in node && node.type !== "TEXT") {
        const bg = fillToCss(node.fills);
        if (bg) styles.background = bg;
      }

      if ("effects" in node && node.effects.length > 0) {
        const shadows = effectsToCss(node.effects);
        if (shadows.length > 0) {
          styles.boxShadow = shadows.join(", ");
        }
      }

      const radius = cornerRadius(node);
      if (radius) {
        styles.borderRadius = radius;
        if ("children" in node && !("clipsContent" in node && node.clipsContent)) {
          styles.overflow = "hidden";
        }
      }

      if ("strokes" in node && "strokeWeight" in node) {
        const border = strokeToCss(node as MinimalStrokesMixin);
        if (border) styles.border = border;
      }

      if ("clipsContent" in node && node.clipsContent) {
        styles.overflow = "hidden";
      }
    }

    return styles;
  }

  private hasImageFill(node: MinimalFillsMixin): boolean {
    if (node.fills === figma.mixed || !node.fills) return false;
    return node.fills.some((fill) => fill.visible !== false && fill.type === "IMAGE");
  }

  private canRenderLineAsCss(node: LineNode): boolean {
    const rotation = Math.abs(node.rotation % 180);
    return rotation < 0.5 || Math.abs(rotation - 90) < 0.5;
  }

  private canRenderEllipseAsCss(node: EllipseNode): boolean {
    const arc = node.arcData;
    return arc.innerRadius === 0 && Math.abs((arc.endingAngle - arc.startingAngle) % 360) < 0.5;
  }

  private needsRasterForSelf(node: SceneNode): boolean {
    if (this.hasMaskChild(node)) return true;
    if (ALWAYS_RASTER_TYPES.has(node.type)) return true;

    if ("fills" in node && this.hasImageFill(node as MinimalFillsMixin)) {
      return true;
    }

    if (node.type === "LINE") {
      return !this.canRenderLineAsCss(node);
    }

    if (node.type === "ELLIPSE") {
      return !this.canRenderEllipseAsCss(node);
    }

    return false;
  }

  private subtreeNeedsRaster(node: SceneNode): boolean {
    if (this.needsRasterForSelf(node)) return true;
    if (!("children" in node)) return false;
    return node.children.some((child) => this.subtreeNeedsRaster(child));
  }

  private hasOwnContainerVisuals(node: SceneNode): boolean {
    if ("fills" in node && node.type !== "TEXT" && fillToCss(node.fills) !== null) {
      return true;
    }

    if ("strokes" in node && "strokeWeight" in node) {
      const border = strokeToCss(node as MinimalStrokesMixin);
      if (border) return true;
    }

    if ("effects" in node && node.effects.length > 0) {
      return effectsToCss(node.effects).length > 0;
    }

    return cornerRadius(node) !== undefined;
  }

  private isCodeRenderableNode(node: SceneNode): boolean {
    if (node.type === "TEXT") return true;
    if (node.type === "RECTANGLE") return true;
    if (node.type === "ELLIPSE") return this.canRenderEllipseAsCss(node);
    if (node.type === "LINE") return this.canRenderLineAsCss(node);
    return false;
  }

  private isGraphicNode(node: SceneNode): boolean {
    return (
      node.type === "RECTANGLE" ||
      node.type === "ELLIPSE" ||
      node.type === "LINE" ||
      node.type === "VECTOR" ||
      node.type === "BOOLEAN_OPERATION" ||
      node.type === "POLYGON" ||
      node.type === "STAR" ||
      node.type === "GROUP"
    );
  }

  private isPureGraphicBundle(node: SceneNode): boolean {
    if (node.type !== "GROUP") return false;
    if (!("children" in node) || node.children.length <= 1) return false;
    if (this.hasTextDescendant(node)) return false;
    if (this.hasOwnContainerVisuals(node)) return false;

    let hasComplexGraphic = false;

    for (const child of node.children) {
      if (!this.isGraphicNode(child)) {
        return false;
      }

      if ("children" in child) {
        if (!this.isPureGraphicBundle(child) && !this.subtreeNeedsRaster(child)) {
          return false;
        }
        hasComplexGraphic = true;
        continue;
      }

      if (!this.isCodeRenderableNode(child)) {
        hasComplexGraphic = true;
      }
    }

    return hasComplexGraphic;
  }

  private hasNestedRasterBundle(node: SceneNode): boolean {
    if (!("children" in node) || node.children.length <= 1) return false;
    if (this.hasTextDescendant(node)) return false;
    if (this.hasOwnContainerVisuals(node)) return false;
    if (this.hasAutoLayout(node)) return false;

    let hasNestedChild = false;

    for (const child of node.children) {
      if (this.isCodeRenderableNode(child)) {
        return false;
      }

      if ("children" in child && child.children.length > 0) {
        hasNestedChild = true;
        if (!this.subtreeNeedsRaster(child)) {
          return false;
        }
        continue;
      }

      if (!this.needsRasterForSelf(child)) {
        return false;
      }
    }

    return hasNestedChild;
  }

  private shouldRasterizeNode(node: SceneNode): boolean {
    if (this.isPureGraphicBundle(node)) return true;
    if (this.hasNestedRasterBundle(node)) return true;
    return this.needsRasterForSelf(node);
  }

  private shouldUseSvgText(node: TextNode): boolean {
    if (node.hasMissingFont) return true;

    const segments = node.getStyledTextSegments([
      "fontName",
      "fontSize",
      "fills",
      "lineHeight",
      "letterSpacing",
      "textCase",
      "textDecoration",
    ]);

    return segments.some((segment) => {
      if (fillToCss(segment.fills) === null) return true;
      if (segment.letterSpacing.unit === "PERCENT") return true;
      if (!LIKELY_HTML_SAFE_FONT_FAMILIES.has(segment.fontName.family)) return true;
      return false;
    });
  }

  private shouldExportAsSvg(node: SceneNode): boolean {
    return (
      this.isPureGraphicBundle(node) ||
      node.type === "VECTOR" ||
      node.type === "BOOLEAN_OPERATION" ||
      node.type === "POLYGON" ||
      node.type === "STAR" ||
      node.type === "LINE" ||
      node.type === "ELLIPSE"
    );
  }

  private makeAssetPath(node: SceneNode, extension: "png" | "svg"): string {
    this.assetIndex += 1;
    const safeName = sanitizeFileSegment(node.name || node.type.toLowerCase());
    return `${IMAGE_DIR_NAME}/${String(this.assetIndex).padStart(3, "0")}-${safeName}.${extension}`;
  }

  private async getRasterSource(
    node: SceneNode & ExportMixin,
    options?: { forceSvg?: boolean; svgOutlineText?: boolean; useAbsoluteBounds?: boolean }
  ): Promise<string | null> {
    try {
      const cached = this.assetCache.get(node.id);
      if (cached) return cached;

      const exportAsSvg = options && typeof options.forceSvg === "boolean"
        ? options.forceSvg
        : this.shouldExportAsSvg(node);
      const bytes = await node.exportAsync(
        exportAsSvg
          ? {
              format: "SVG",
              contentsOnly: true,
              useAbsoluteBounds:
                options && typeof options.useAbsoluteBounds === "boolean"
                  ? options.useAbsoluteBounds
                  : false,
              svgOutlineText: options && typeof options.svgOutlineText === "boolean"
                ? options.svgOutlineText
                : true,
            }
          : {
              format: "PNG",
              constraint: { type: "SCALE", value: 2 },
            }
      );
      const base64 = figma.base64Encode(bytes);
      const mimeType = exportAsSvg ? "image/svg+xml" : "image/png";
      const extension = exportAsSvg ? "svg" : "png";
      const contentKey = `${mimeType}:${base64}`;

      if (this.assetMode === "inline") {
        const existingDataUrl = this.assetContentCache.get(contentKey);
        if (existingDataUrl) {
          this.assetCache.set(node.id, existingDataUrl);
          return existingDataUrl;
        }

        const dataUrl = `data:${mimeType};base64,${base64}`;
        this.assetContentCache.set(contentKey, dataUrl);
        this.assetCache.set(node.id, dataUrl);
        return dataUrl;
      }

      const existingPath = this.assetContentCache.get(contentKey);
      if (existingPath) {
        this.assetCache.set(node.id, existingPath);
        return existingPath;
      }

      const path = this.makeAssetPath(node, extension);
      this.assets.push({
        path,
        base64,
        mimeType,
      });
      this.assetContentCache.set(contentKey, path);
      this.assetCache.set(node.id, path);
      return path;
    } catch {
      return null;
    }
  }

  private typeClass(node: SceneNode): string {
    return `figma-${node.type.toLowerCase().replace(/_/g, "-")}`;
  }

  private applyShapeStyles(node: SceneNode, styles: Record<string, string>): void {
    if (node.type === "ELLIPSE") {
      styles.borderRadius = "50%";
      return;
    }

    if (node.type === "LINE") {
      const stroke = getStrokeDescriptor(node);
      delete styles.border;
      delete styles.background;
      styles.height = `${Math.max(stroke ? stroke.weight : 1, 1)}px`;
      if (stroke) {
        styles.borderTop = `${stroke.weight}px ${stroke.style} ${stroke.color}`;
      }
      return;
    }
  }

  private getDashPattern(node: SceneNode): ReadonlyArray<number> {
    if (!("dashPattern" in node) || !Array.isArray(node.dashPattern)) {
      return [];
    }
    return node.dashPattern;
  }

  private isLineLikeRectangle(node: SceneNode): boolean {
    if (
      node.type !== "RECTANGLE" &&
      node.type !== "FRAME" &&
      node.type !== "COMPONENT" &&
      node.type !== "INSTANCE"
    ) {
      return false;
    }

    if (!("absoluteBoundingBox" in node) || !node.absoluteBoundingBox) return false;
    if (!("strokes" in node) || !("strokeWeight" in node)) return false;

    const stroke = getStrokeDescriptor(node as MinimalStrokesMixin & { strokeWeight?: number | typeof figma.mixed });
    if (!stroke) return false;

    const hasFill = "fills" in node && fillToCss(node.fills) !== null;
    if (hasFill) return false;

    const box = node.absoluteBoundingBox;
    return box.height <= Math.max(stroke.weight * 2, 2) || box.width <= Math.max(stroke.weight * 2, 2);
  }

  private applyLineStyles(node: SceneNode, styles: Record<string, string>): void {
    const stroke = getStrokeDescriptor(
      node as MinimalStrokesMixin & { strokeWeight?: number | typeof figma.mixed }
    );
    if (!stroke || !("absoluteBoundingBox" in node) || !node.absoluteBoundingBox) return;

    const box = node.absoluteBoundingBox;
    const horizontal = box.width >= box.height;
    const dashPattern = this.getDashPattern(node);
    const dash = dashPattern.length > 0 ? Math.max(dashPattern[0], 1) : Math.max(stroke.weight * 2, 2);
    const gap = dashPattern.length > 1 ? Math.max(dashPattern[1], 1) : dash;

    delete styles.border;
    delete styles.borderRadius;
    delete styles.boxShadow;
    delete styles.background;

    if (horizontal) {
      styles.height = `${Math.max(stroke.weight, 1)}px`;
      styles.width = `${box.width}px`;
      if (stroke.style === "dashed") {
        styles.backgroundImage = `repeating-linear-gradient(to right, ${stroke.color} 0 ${dash}px, transparent ${dash}px ${dash + gap}px)`;
        styles.backgroundColor = "transparent";
      } else {
        styles.background = stroke.color;
      }
      return;
    }

    styles.width = `${Math.max(stroke.weight, 1)}px`;
    styles.height = `${box.height}px`;
    if (stroke.style === "dashed") {
      styles.backgroundImage = `repeating-linear-gradient(to bottom, ${stroke.color} 0 ${dash}px, transparent ${dash}px ${dash + gap}px)`;
      styles.backgroundColor = "transparent";
    } else {
      styles.background = stroke.color;
    }
  }

  private textCaseToCss(value: TextCase): Record<string, string> {
    if (value === "UPPER") return { textTransform: "uppercase" };
    if (value === "LOWER") return { textTransform: "lowercase" };
    if (value === "TITLE") return { textTransform: "capitalize" };
    if (value === "SMALL_CAPS" || value === "SMALL_CAPS_FORCED") {
      return { fontVariant: "small-caps" };
    }
    return {};
  }

  private textDecorationToCss(value: TextDecoration): string | undefined {
    if (value === "UNDERLINE") return "underline";
    if (value === "STRIKETHROUGH") return "line-through";
    return undefined;
  }

  private lineHeightToCss(value: LineHeight): string | undefined {
    if (value.unit === "PIXELS") return `${value.value}px`;
    if (value.unit === "PERCENT") return `${value.value}%`;
    if (value.unit === "AUTO") return "normal";
    return undefined;
  }

  private normalizeFontFamily(fontName?: FontName | PluginAPI["mixed"]): string | undefined {
    if (!fontName || fontName === figma.mixed) return `"Pretendard", sans-serif`;
    const family = fontName.family.trim();
    if (!family) return `"Pretendard", sans-serif`;
    return `"${family}", "Pretendard", sans-serif`;
  }

  private applyTextStyleFallback(
    styles: Record<string, string>,
    source: {
      fontName?: FontName | PluginAPI["mixed"];
      fontSize?: number | PluginAPI["mixed"];
      lineHeight?: LineHeight | PluginAPI["mixed"];
      letterSpacing?: LetterSpacing | PluginAPI["mixed"];
      fills?: readonly Paint[] | PluginAPI["mixed"];
      textCase?: TextCase | PluginAPI["mixed"];
      textDecoration?: TextDecoration | PluginAPI["mixed"];
    }
  ): void {
    if (source.fontName && source.fontName !== figma.mixed) {
      const normalizedFamily = this.normalizeFontFamily(source.fontName);
      if (normalizedFamily) {
        styles.fontFamily = normalizedFamily;
      }
      if (source.fontName.style.toLowerCase().includes("italic")) {
        styles.fontStyle = "italic";
      }
    }

    if (typeof source.fontSize === "number") {
      styles.fontSize = `${source.fontSize}px`;
    }

    if (source.lineHeight && source.lineHeight !== figma.mixed) {
      const lineHeight = this.lineHeightToCss(source.lineHeight);
      if (lineHeight) styles.lineHeight = lineHeight;
    }

    if (source.letterSpacing && source.letterSpacing !== figma.mixed) {
      if (source.letterSpacing.unit === "PIXELS") {
        styles.letterSpacing = `${source.letterSpacing.value}px`;
      }
    }

    if (source.fills && source.fills !== figma.mixed) {
      const fill = fillToCss(source.fills);
      if (fill) styles.color = fill;
    }

    if (source.textCase && source.textCase !== figma.mixed) {
      Object.assign(styles, this.textCaseToCss(source.textCase));
    }

    if (source.textDecoration && source.textDecoration !== figma.mixed) {
      const textDecoration = this.textDecorationToCss(source.textDecoration);
      if (textDecoration) styles.textDecoration = textDecoration;
    }
  }

  private renderTextSegments(node: TextNode): string {
    const segments = node.getStyledTextSegments([
      "fontName",
      "fontWeight",
      "fontSize",
      "lineHeight",
      "letterSpacing",
      "fills",
      "textCase",
      "textDecoration",
    ]);

    if (segments.length === 0) {
      return escapeHtml(node.characters);
    }

    return segments
      .map((segment) => {
        const styles: Record<string, string> = {
          fontWeight: `${segment.fontWeight}`,
        };
        this.applyTextStyleFallback(styles, segment);

        const content = escapeHtml(segment.characters);
        return `<span style="${escapeHtml(cssObject(styles))}">${content}</span>`;
      })
      .join("");
  }

  private async nodeToHtml(
    node: SceneNode,
    root: Bounds,
    options: ExportOptions,
    isRootChild = false,
    origin: Origin = { x: root.x, y: root.y }
  ): Promise<string> {
    if (!options.includeHidden && !node.visible) return "";
    this.nodeCount++;

    const typeClass = this.typeClass(node);
    const dataName = escapeHtml(node.name);
    const useAbsolute = isRootChild || !this.parentUsesAutoLayout(node);

    if (node.type === "TEXT") {
      if (this.shouldUseSvgText(node)) {
        const src = await this.getRasterSource(node as TextNode & ExportMixin, {
          forceSvg: true,
          svgOutlineText: true,
          useAbsoluteBounds: false,
        });
        if (src) {
          const styles = this.baseStyles(node, origin, useAbsolute, false);
          const attrs = this.styleAttrs(node, styles, "figma-text");
          return `    <img${attrs} data-figma-name="${dataName}" alt="${dataName}" src="${src}" />`;
        }
      }

      return this.textToHtml(node, origin, useAbsolute);
    }

    if (this.shouldRasterizeNode(node) && "exportAsync" in node) {
      const src = await this.getRasterSource(node as SceneNode & ExportMixin);
      if (src) {
        const styles = this.baseStyles(node, origin, useAbsolute, false);
        const attrs = this.styleAttrs(node, styles, typeClass);
        return `    <img${attrs} data-figma-name="${dataName}" alt="${dataName}" src="${src}" />`;
      }
    }

    const styles: Record<string, string> = {
      ...this.baseStyles(node, origin, useAbsolute),
    };

    if (this.hasAutoLayout(node)) {
      Object.assign(styles, this.layoutStyles(node));
    }

    if (node.type === "LINE" || this.isLineLikeRectangle(node)) {
      this.applyLineStyles(node, styles);
    } else {
      this.applyShapeStyles(node, styles);
    }

    const children: string[] = [];
    if ("children" in node) {
      const childOrigin = this.getAbsoluteOrigin(node) || origin;
      const childNodes = (node as ChildrenMixin).children.filter(
        (child) => options.includeHidden || child.visible
      );
      for (const child of childNodes) {
        const childHtml = await this.nodeToHtml(child, root, options, false, childOrigin);
        if (childHtml) children.push(childHtml);
      }
    }

    if (children.length > 0 && !styles.position) {
      styles.position = "relative";
    }

    const attrs = this.styleAttrs(node, styles, typeClass);
    if (!CONTAINER_TYPES.has(node.type) && children.length === 0 && node.type !== "SLICE") {
      return `    <div${attrs} data-figma-name="${dataName}"></div>`;
    }

    const inner = children.length > 0 ? `\n${children.join("\n")}\n    ` : "";
    return `    <div${attrs} data-figma-name="${dataName}">${inner}</div>`;
  }

  private textToHtml(node: TextNode, origin: Origin, useAbsolute: boolean): string {
    const styles = this.baseStyles(node, origin, useAbsolute);
    delete styles.background;

    if (node.textAutoResize === "HEIGHT") {
      delete styles.height;
    } else if (node.textAutoResize === "WIDTH_AND_HEIGHT") {
      delete styles.height;
      delete styles.width;
    }

    if (node.textAlignHorizontal) {
      const align: Record<string, string> = {
        LEFT: "left",
        CENTER: "center",
        RIGHT: "right",
        JUSTIFIED: "justify",
      };
      styles.textAlign = align[node.textAlignHorizontal] || "left";
    }

    if (node.textAutoResize === "TRUNCATE") {
      styles.overflow = "hidden";
      styles.textOverflow = "ellipsis";
      styles.whiteSpace = "nowrap";
    }

    styles.display = "block";

    const attrs = this.styleAttrs(node, styles, "figma-text");
    const innerStyleObject: Record<string, string> = {
      display: "block",
      width: "100%",
      whiteSpace: "pre-wrap",
      wordBreak: "break-word",
    };
    this.applyTextStyleFallback(innerStyleObject, node);
    const innerStyles = cssObject(innerStyleObject);
    const content = this.renderTextSegments(node);

    return `    <div${attrs} data-figma-name="${escapeHtml(node.name)}"><div style="${escapeHtml(innerStyles)}">${content}</div></div>`;
  }
}

export async function collectNodesForScope(scope: ExportOptions["scope"]): Promise<SceneNode[]> {
  if (scope === "selection") {
    return [...figma.currentPage.selection];
  }

  if (scope === "all-pages") {
    const nodes: SceneNode[] = [];
    for (const page of figma.root.children) {
      if (page.type !== "PAGE") continue;
      nodes.push(...page.children);
    }
    return nodes;
  }

  return [...figma.currentPage.children];
}
