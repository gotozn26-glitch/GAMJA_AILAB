export type ExportScope = "page" | "selection" | "all-pages";
export type CssOutputMode = "inline" | "external";
export type AssetOutputMode = "inline" | "external";

export interface ExportOptions {
  scope: ExportScope;
  includeHidden: boolean;
  cssMode: CssOutputMode;
  assetMode: AssetOutputMode;
}

export interface ExportAsset {
  path: string;
  base64: string;
  mimeType: string;
}

export interface ExportResult {
  html: string;
  css: string | null;
  cssMode: CssOutputMode;
  assetMode: AssetOutputMode;
  assets: ExportAsset[];
  width: number;
  height: number;
  nodeCount: number;
  pageName: string;
}
