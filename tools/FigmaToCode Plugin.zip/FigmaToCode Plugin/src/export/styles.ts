export function rgba(paint: SolidPaint): string {
  const { r, g, b } = paint.color;
  const a = paint.opacity ?? 1;
  return `rgba(${Math.round(r * 255)}, ${Math.round(g * 255)}, ${Math.round(
    b * 255
  )}, ${a})`;
}

export function fillToCss(fills: readonly Paint[] | typeof figma.mixed): string | null {
  if (fills === figma.mixed || !fills || fills.length === 0) return null;
  const visible = fills.filter((f) => f.visible !== false);
  if (visible.length === 0) return null;

  const paint = visible[visible.length - 1];
  if (paint.type === "SOLID") return rgba(paint);
  if (paint.type === "GRADIENT_LINEAR" || paint.type === "GRADIENT_RADIAL") {
    const stops = paint.gradientStops
      .map((s) => `${rgba({ ...s, type: "SOLID", opacity: s.color.a } as SolidPaint)} ${Math.round(s.position * 100)}%`)
      .join(", ");
    return paint.type === "GRADIENT_LINEAR"
      ? `linear-gradient(180deg, ${stops})`
      : `radial-gradient(circle, ${stops})`;
  }
  return null;
}

export function escapeHtml(text: string): string {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

export function cssObject(styles: Record<string, string | number | undefined | null>): string {
  return Object.entries(styles)
    .filter(([, v]) => v !== undefined && v !== null && v !== "")
    .map(([k, v]) => `${k.replace(/[A-Z]/g, (m) => `-${m.toLowerCase()}`)}: ${v}`)
    .join("; ");
}

export function cornerRadius(node: SceneNode): string | undefined {
  if (!("cornerRadius" in node)) return undefined;
  const cr = node.cornerRadius;
  if (typeof cr === "number" && cr > 0) return `${cr}px`;
  if (cr === figma.mixed && "topLeftRadius" in node) {
    const r = node as RectangleNode;
    return `${r.topLeftRadius}px ${r.topRightRadius}px ${r.bottomRightRadius}px ${r.bottomLeftRadius}px`;
  }
  return undefined;
}

export function effectsToCss(effects: readonly Effect[]): string[] {
  const parts: string[] = [];
  for (const e of effects) {
    if (e.visible === false) continue;
    if (e.type === "DROP_SHADOW") {
      const c = e.color;
      parts.push(
        `${e.offset.x}px ${e.offset.y}px ${e.radius}px ${e.spread ?? 0}px rgba(${Math.round(c.r * 255)}, ${Math.round(c.g * 255)}, ${Math.round(c.b * 255)}, ${c.a})`
      );
    }
    if (e.type === "INNER_SHADOW") {
      const c = e.color;
      parts.push(
        `inset ${e.offset.x}px ${e.offset.y}px ${e.radius}px rgba(${Math.round(c.r * 255)}, ${Math.round(c.g * 255)}, ${Math.round(c.b * 255)}, ${c.a})`
      );
    }
  }
  return parts;
}

export function strokeToCss(node: MinimalStrokesMixin): string | undefined {
  const strokes = node.strokes;
  if (!strokes || strokes.length === 0) return undefined;
  const stroke = strokes.find((s) => s.visible !== false && s.type === "SOLID") as SolidPaint | undefined;
  if (!stroke) return undefined;
  const weight = typeof node.strokeWeight === "number" ? node.strokeWeight : 1;
  const style =
    "dashPattern" in node && Array.isArray(node.dashPattern) && node.dashPattern.length > 0
      ? "dashed"
      : "solid";
  return `${weight}px ${style} ${rgba(stroke)}`;
}

export interface StrokeDescriptor {
  color: string;
  style: "solid" | "dashed";
  weight: number;
}

export function getStrokeDescriptor(
  node: MinimalStrokesMixin & {
    strokeWeight?: number | typeof figma.mixed;
    dashPattern?: ReadonlyArray<number>;
  }
): StrokeDescriptor | null {
  const strokes = node.strokes;
  if (!strokes || strokes.length === 0) return null;
  const stroke = strokes.find((s) => s.visible !== false && s.type === "SOLID") as SolidPaint | undefined;
  if (!stroke) return null;

  return {
    color: rgba(stroke),
    style: Array.isArray(node.dashPattern) && node.dashPattern.length > 0 ? "dashed" : "solid",
    weight: typeof node.strokeWeight === "number" ? node.strokeWeight : 1,
  };
}

export function sanitizeFileSegment(value: string): string {
  const sanitized = value
    .trim()
    .replace(/[^a-zA-Z0-9-_]+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "");

  return sanitized || "asset";
}
