import JSZip from "jszip";

export const CSS_FILE_NAME = "styles.css";

export type ZipFileEntry =
  | { path: string; content: string }
  | { path: string; base64: string; mimeType: string };

export async function buildExportZip(files: ZipFileEntry[]): Promise<Blob> {
  const zip = new JSZip();
  for (const file of files) {
    if ("base64" in file) {
      zip.file(file.path, file.base64, { base64: true });
    } else {
      zip.file(file.path, file.content);
    }
  }
  return zip.generateAsync({ type: "blob" });
}

export function downloadBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
