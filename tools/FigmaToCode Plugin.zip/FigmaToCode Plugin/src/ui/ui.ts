import { buildExportZip, CSS_FILE_NAME, downloadBlob, ZipFileEntry } from "./zipDownload";

type AssetMode = "inline" | "external";
type CssMode = "inline" | "external";
type ExportAsset = { path: string; base64: string; mimeType: string };

const exportBtn = document.getElementById("export") as HTMLButtonElement;
const copyHtmlBtn = document.getElementById("copyHtml") as HTMLButtonElement;
const copyCssBtn = document.getElementById("copyCss") as HTMLButtonElement;
const downloadBtn = document.getElementById("download") as HTMLButtonElement;
const downloadCssBtn = document.getElementById("downloadCss") as HTMLButtonElement;
const downloadZipBtn = document.getElementById("downloadZip") as HTMLButtonElement;
const statusEl = document.getElementById("status") as HTMLDivElement;
const includeHiddenEl = document.getElementById("includeHidden") as HTMLInputElement;

let lastHtml = "";
let lastCss: string | null = null;
let lastCssMode: CssMode = "inline";
let lastAssetMode: AssetMode = "external";
let lastAssets: ExportAsset[] = [];
let lastPageName = "figma-export";

function getScope(): "page" | "selection" | "all-pages" {
  const checked = document.querySelector<HTMLInputElement>('input[name="scope"]:checked');
  return checked && checked.value ? (checked.value as "page" | "selection" | "all-pages") : "page";
}

function getCssMode(): CssMode {
  const checked = document.querySelector<HTMLInputElement>('input[name="cssMode"]:checked');
  return checked && checked.value ? (checked.value as CssMode) : "inline";
}

function getAssetMode(): AssetMode {
  const checked = document.querySelector<HTMLInputElement>('input[name="assetMode"]:checked');
  return checked && checked.value ? (checked.value as AssetMode) : "external";
}

function setStatus(text: string, isError = false) {
  statusEl.textContent = text;
  statusEl.style.color = isError ? "var(--figma-color-text-danger)" : "var(--figma-color-text-secondary)";
}

function setLoading(loading: boolean) {
  exportBtn.disabled = loading;
  exportBtn.textContent = loading ? "변환 중…" : "HTML보내기";
}

function setExternalCssUi(externalCss: boolean) {
  copyCssBtn.style.display = externalCss ? "block" : "none";
  downloadCssBtn.style.display = externalCss ? "block" : "none";
}

function resetOutputButtons() {
  copyHtmlBtn.disabled = true;
  copyCssBtn.disabled = true;
  downloadBtn.disabled = true;
  downloadCssBtn.disabled = true;
  downloadZipBtn.disabled = true;
}

function sanitizeFilename(name: string): string {
  return name.replace(/[<>:"/\\|?*]/g, "-").trim() || "figma-export";
}

function htmlFilename(): string {
  return `${sanitizeFilename(lastPageName)}.html`;
}

function zipFilename(): string {
  return `${sanitizeFilename(lastPageName)}.zip`;
}

function getExportFiles(): ZipFileEntry[] {
  const files: ZipFileEntry[] = [{ path: htmlFilename(), content: lastHtml }];
  if (lastCss) {
    files.push({ path: CSS_FILE_NAME, content: lastCss });
  }
  for (const asset of lastAssets) {
    files.push(asset);
  }
  return files;
}

exportBtn.onclick = () => {
  setLoading(true);
  setStatus("변환을 시작합니다…");
  resetOutputButtons();
  parent.postMessage(
    {
      pluginMessage: {
        type: "export",
        scope: getScope(),
        includeHidden: includeHiddenEl.checked,
        cssMode: getCssMode(),
        assetMode: getAssetMode(),
      },
    },
    "*"
  );
};

copyHtmlBtn.onclick = async () => {
  if (!lastHtml) return;
  try {
    await navigator.clipboard.writeText(lastHtml);
    setStatus(
      lastAssetMode === "external"
        ? "HTML이 복사되었습니다. image/ 폴더는 ZIP 다운로드를 사용하세요."
        : "HTML이 클립보드에 복사되었습니다."
    );
  } catch {
    setStatus("복사에 실패했습니다. 다운로드를 사용하세요.", true);
  }
};

copyCssBtn.onclick = async () => {
  if (!lastCss) return;
  try {
    await navigator.clipboard.writeText(lastCss);
    setStatus("CSS가 클립보드에 복사되었습니다.");
  } catch {
    setStatus("복사에 실패했습니다. 다운로드를 사용하세요.", true);
  }
};

downloadBtn.onclick = () => {
  if (!lastHtml) return;
  downloadBlob(new Blob([lastHtml], { type: "text/html;charset=utf-8" }), htmlFilename());

  if (lastAssetMode === "external") {
    setStatus("HTML만 다운로드되었습니다. 서버 업로드용은 ZIP으로 받는 것을 권장합니다.");
    return;
  }

  setStatus(
    lastCssMode === "external"
      ? "HTML 다운로드됨. CSS는 별도 버튼 또는 ZIP을 사용하세요."
      : "HTML 다운로드가 시작되었습니다."
  );
};

downloadCssBtn.onclick = () => {
  if (!lastCss) return;
  downloadBlob(new Blob([lastCss], { type: "text/css;charset=utf-8" }), CSS_FILE_NAME);
  setStatus("styles.css 다운로드가 시작되었습니다.");
};

downloadZipBtn.onclick = async () => {
  if (!lastHtml) return;

  downloadZipBtn.disabled = true;
  setStatus("ZIP 파일을 만드는 중…");

  try {
    const blob = await buildExportZip(getExportFiles());
    downloadBlob(blob, zipFilename());

    const assetNote =
      lastAssets.length > 0 ? `, image/ ${lastAssets.length}개` : "";
    setStatus(`ZIP 다운로드 완료 (${htmlFilename()}${assetNote})`);
  } catch {
    setStatus("ZIP 생성에 실패했습니다.", true);
  } finally {
    downloadZipBtn.disabled = false;
  }
};

window.onmessage = (event: MessageEvent) => {
  const msg = event.data.pluginMessage;
  if (!msg) return;

  if (msg.type === "status") {
    setStatus(msg.message);
    return;
  }

  if (msg.type === "error") {
    setLoading(false);
    setStatus(msg.message, true);
    return;
  }

  if (msg.type === "success") {
    setLoading(false);
    lastHtml = msg.html;
    lastCss = msg.css || null;
    lastCssMode = msg.cssMode || "inline";
    lastAssetMode = msg.assetMode || "external";
    lastAssets = Array.isArray(msg.assets) ? (msg.assets as ExportAsset[]) : [];
    lastPageName = msg.pageName;

    const externalCss = lastCssMode === "external";
    setExternalCssUi(externalCss);

    copyHtmlBtn.disabled = false;
    downloadBtn.disabled = false;
    downloadZipBtn.disabled = false;
    copyCssBtn.disabled = !externalCss || !lastCss;
    downloadCssBtn.disabled = !externalCss || !lastCss;

    const cssNote = externalCss ? ", styles.css 분리" : "";
    const assetNote = lastAssets.length > 0 ? `, image ${lastAssets.length}개` : "";
    setStatus(
      `완료 — ${msg.nodeCount}개 노드, ${Math.round(msg.width)}×${Math.round(msg.height)}px${cssNote}${assetNote}`
    );
  }
};
