import { collectNodesForScope, HtmlExporter } from "./export/htmlExporter";
import type { AssetOutputMode, CssOutputMode, ExportOptions, ExportScope } from "./export/types";

figma.showUI(__html__, { width: 360, height: 580, themeColors: true });

figma.ui.onmessage = async (msg: {
  type: string;
  scope?: ExportScope;
  includeHidden?: boolean;
  cssMode?: CssOutputMode;
  assetMode?: AssetOutputMode;
}) => {
  if (msg.type === "cancel") {
    figma.closePlugin();
    return;
  }

  if (msg.type !== "export") return;

  const options: ExportOptions = {
    scope: msg.scope ?? "page",
    includeHidden: msg.includeHidden ?? false,
    cssMode: msg.cssMode ?? "inline",
    assetMode: msg.assetMode ?? "external",
  };

  try {
    figma.ui.postMessage({ type: "status", message: "노드를 수집하는 중…" });

    const nodes = await collectNodesForScope(options.scope);

    if (nodes.length === 0) {
      figma.ui.postMessage({
        type: "error",
        message:
          options.scope === "selection"
            ? "선택된 레이어가 없습니다. 프레임을 선택하거나 '현재 페이지 전체'를 사용하세요."
            : "현재 페이지에보낼 레이어가 없습니다.",
      });
      return;
    }

    figma.ui.postMessage({ type: "status", message: "HTML로 변환하는 중…" });

    const exporter = new HtmlExporter();
    const result = await exporter.export(nodes, options);

    figma.ui.postMessage({
      type: "success",
      html: result.html,
      css: result.css,
      cssMode: result.cssMode,
      assetMode: result.assetMode,
      assets: result.assets,
      width: result.width,
      height: result.height,
      nodeCount: result.nodeCount,
      pageName: result.pageName,
    });

    figma.notify(`HTML보내기 완료 (${result.nodeCount}개 노드)`);
  } catch (err) {
    const message = err instanceof Error ? err.message : "알 수 없는 오류가 발생했습니다.";
    figma.ui.postMessage({ type: "error", message });
    figma.notify(`보내기 실패: ${message}`, { error: true });
  }
};
