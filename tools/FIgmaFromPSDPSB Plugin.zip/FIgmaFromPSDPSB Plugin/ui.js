"use strict";
(() => {
  // src/psdParser.ts
  var layerCounter = 0;
  function nextId() {
    layerCounter += 1;
    return `layer-${layerCounter}`;
  }
  function layerBounds(layer) {
    const left = layer.left ?? 0;
    const top = layer.top ?? 0;
    const right = layer.right ?? left;
    const bottom = layer.bottom ?? top;
    return {
      left,
      top,
      width: Math.max(1, right - left),
      height: Math.max(1, bottom - top)
    };
  }
  function canvasToPngBytes(canvas) {
    return new Promise((resolve, reject) => {
      canvas.toBlob((blob) => {
        if (!blob) {
          reject(new Error("Failed to encode layer image"));
          return;
        }
        blob.arrayBuffer().then((buffer) => resolve(Array.from(new Uint8Array(buffer))));
      }, "image/png");
    });
  }
  function convertFill(layer) {
    if (layer.vectorFill?.color) {
      return {
        type: "solid",
        color: {
          r: layer.vectorFill.color.r,
          g: layer.vectorFill.color.g,
          b: layer.vectorFill.color.b
        },
        opacity: layer.vectorFill.opacity ?? 1
      };
    }
    if (layer.solidColor) {
      return {
        type: "solid",
        color: {
          r: layer.solidColor.r,
          g: layer.solidColor.g,
          b: layer.solidColor.b
        },
        opacity: layer.opacity ?? 1
      };
    }
    return void 0;
  }
  function convertStroke(layer) {
    const stroke = layer.vectorStroke;
    if (!stroke || stroke.fillEnabled === false) return void 0;
    const color = stroke.content?.color;
    if (!color) return void 0;
    let align = "center";
    if (stroke.lineAlignment === "inside") align = "inside";
    if (stroke.lineAlignment === "outside") align = "outside";
    const lineWidth = typeof stroke.lineWidth === "object" && stroke.lineWidth !== null ? stroke.lineWidth.value : stroke.lineWidth ?? 1;
    return {
      color: { r: color.r, g: color.g, b: color.b },
      weight: lineWidth,
      opacity: stroke.opacity ?? 1,
      align,
      dashPattern: stroke.lineDashSet?.map((d) => d.value)
    };
  }
  function convertVectorPaths(layer) {
    if (!layer.vectorMask?.paths?.length) return void 0;
    return layer.vectorMask.paths.map((path) => ({
      windingRule: path.operation === "exclude" ? "EVENODD" : "NONZERO",
      data: bezierPathToSvg(path.knots, path.open)
    }));
  }
  function bezierPathToSvg(knots, open) {
    if (!knots.length) return "";
    const parts = [];
    const first = knots[0].points;
    parts.push(`M ${first[2]} ${first[3]}`);
    for (let i = 0; i < knots.length; i++) {
      const current = knots[i].points;
      const next = knots[(i + 1) % knots.length].points;
      if (open && i === knots.length - 1) break;
      parts.push(`C ${current[4]} ${current[5]} ${next[0]} ${next[1]} ${next[2]} ${next[3]}`);
    }
    if (!open) parts.push("Z");
    return parts.join(" ");
  }
  function parseFontFamily(fontName) {
    if (!fontName) return { family: "Inter", style: "Regular" };
    let family = fontName.replace(/[-_]/g, " ").replace(/\bMT\b/gi, "").replace(/\bPS\b/gi, "").replace(/\bStd\b/gi, "").trim();
    const stylePatterns = [
      [/bold\s*italic|italic\s*bold/i, "Bold Italic"],
      [/\bbold\b/i, "Bold"],
      [/\bitalic\b|\boblique\b/i, "Italic"]
    ];
    let style = "Regular";
    for (const [pattern, matchedStyle] of stylePatterns) {
      if (pattern.test(family)) {
        style = matchedStyle;
        family = family.replace(pattern, "").trim();
        break;
      }
    }
    if (!family) family = "Inter";
    return { family, style };
  }
  function mapRunFontStyle(style) {
    const name = style.font?.name ?? "";
    const lower = name.toLowerCase();
    if (lower.includes("bold") && (lower.includes("italic") || lower.includes("oblique"))) return "Bold Italic";
    if (lower.includes("bold") || style.fauxBold) return "Bold";
    if (lower.includes("italic") || lower.includes("oblique") || style.fauxItalic) return "Italic";
    return "Regular";
  }
  function mapJustification(justification) {
    switch (justification) {
      case "center":
        return "center";
      case "right":
        return "right";
      case "justifyAll":
      case "justifyLeft":
      case "justifyCenter":
      case "justifyRight":
        return "justify";
      default:
        return "left";
    }
  }
  function convertText(layer) {
    const textData = layer.text;
    if (!textData) return void 0;
    const style = textData.style ?? {};
    const paragraphStyle = textData.paragraphStyle ?? {};
    const fontInfo = parseFontFamily(style.font?.name);
    const transform = textData.transform ?? [1, 0, 0, 1, 0, 0];
    const styleRuns = [];
    if (textData.styleRuns?.length) {
      let offset = 0;
      for (const run of textData.styleRuns) {
        const runStyle = run.style ?? {};
        const runFont = parseFontFamily(runStyle.font?.name ?? style.font?.name);
        styleRuns.push({
          start: offset,
          end: offset + run.length,
          fontFamily: runFont.family,
          fontStyle: mapRunFontStyle(runStyle),
          fontSize: runStyle.fontSize ?? style.fontSize ?? 16,
          fillColor: runStyle.fillColor ? { r: runStyle.fillColor.r, g: runStyle.fillColor.g, b: runStyle.fillColor.b } : style.fillColor ? { r: style.fillColor.r, g: style.fillColor.g, b: style.fillColor.b } : void 0,
          fauxBold: runStyle.fauxBold,
          fauxItalic: runStyle.fauxItalic,
          underline: runStyle.underline,
          strikethrough: runStyle.strikethrough,
          letterSpacing: runStyle.tracking ? runStyle.tracking / 1e3 * (runStyle.fontSize ?? style.fontSize ?? 16) : void 0
        });
        offset += run.length;
      }
    }
    const fillColor = style.fillColor ? { r: style.fillColor.r, g: style.fillColor.g, b: style.fillColor.b } : { r: 0, g: 0, b: 0 };
    return {
      content: textData.text ?? "",
      fontFamily: fontInfo.family,
      fontStyle: mapRunFontStyle(style),
      fontSize: style.fontSize ?? 16,
      fillColor,
      lineHeight: style.leading && style.fontSize ? style.leading / style.fontSize : void 0,
      letterSpacing: style.tracking ? style.tracking / 1e3 * (style.fontSize ?? 16) : void 0,
      textAlign: mapJustification(paragraphStyle.justification),
      textCase: style.fontCaps === 2 ? "UPPER" : "ORIGINAL",
      textDecoration: style.underline ? "UNDERLINE" : style.strikethrough ? "STRIKETHROUGH" : "NONE",
      transform,
      boxWidth: textData.bounds?.right?.value !== void 0 && textData.bounds?.left?.value !== void 0 ? textData.bounds.right.value - textData.bounds.left.value : void 0,
      boxHeight: textData.bounds?.bottom?.value !== void 0 && textData.bounds?.top?.value !== void 0 ? textData.bounds.bottom.value - textData.bounds.top.value : void 0,
      styleRuns: styleRuns.length ? styleRuns : void 0
    };
  }
  function shadowFromPsd(shadow) {
    const angleRad = (shadow.angle ?? 120) * Math.PI / 180;
    const distance = shadow.distance?.value ?? 0;
    return {
      color: shadow.color ?? { r: 0, g: 0, b: 0 },
      opacity: shadow.opacity ?? 0.75,
      offsetX: Math.round(Math.cos(angleRad) * distance),
      offsetY: Math.round(Math.sin(angleRad) * distance),
      blur: shadow.size?.value ?? 0,
      spread: shadow.choke?.value ?? 0
    };
  }
  function convertEffects(layer) {
    const effects = layer.effects;
    if (!effects) return void 0;
    const result = {};
    if (effects.dropShadow?.length) {
      result.dropShadow = effects.dropShadow.filter((s) => s.enabled !== false).map((s) => shadowFromPsd(s));
    }
    if (effects.innerShadow?.length) {
      result.innerShadow = effects.innerShadow.filter((s) => s.enabled !== false).map((s) => shadowFromPsd(s));
    }
    return result.dropShadow?.length || result.innerShadow?.length ? result : void 0;
  }
  function detectLayerKind(layer) {
    if (layer.children?.length) return "group";
    if (layer.text) return "text";
    if (layer.adjustment) return "adjustment";
    if (layer.placedLayer) return "smartObject";
    if (layer.vectorMask && (layer.vectorFill || layer.vectorStroke)) return "vector";
    if (layer.vectorMask) return "vector";
    return "image";
  }
  async function convertLayer(layer, onProgress) {
    const bounds = layerBounds(layer);
    const kind = detectLayerKind(layer);
    const id = nextId();
    onProgress?.(`Converting: ${layer.name ?? id}`);
    const importLayer = {
      id,
      name: layer.name ?? "Layer",
      kind,
      left: bounds.left,
      top: bounds.top,
      width: bounds.width,
      height: bounds.height,
      opacity: layer.opacity ?? 1,
      visible: !layer.hidden,
      blendMode: layer.blendMode ?? "normal",
      clipped: !!layer.clipping,
      fill: convertFill(layer),
      stroke: convertStroke(layer),
      vectorPaths: convertVectorPaths(layer),
      text: kind === "text" ? convertText(layer) : void 0,
      effects: convertEffects(layer),
      isMask: !!layer.mask,
      maskFromVector: layer.mask?.fromVectorData
    };
    if (kind === "group" && layer.children?.length) {
      importLayer.children = [];
      for (const child of layer.children) {
        importLayer.children.push(await convertLayer(child, onProgress));
      }
    } else if (layer.canvas && kind !== "text" && kind !== "vector") {
      try {
        importLayer.imageBytes = await canvasToPngBytes(layer.canvas);
        importLayer.imageFormat = "png";
      } catch {
      }
    } else if (kind === "vector" && layer.canvas && !importLayer.vectorPaths?.length) {
      try {
        importLayer.imageBytes = await canvasToPngBytes(layer.canvas);
        importLayer.imageFormat = "png";
        importLayer.kind = "image";
      } catch {
      }
    }
    return importLayer;
  }
  async function parsePsdFile(buffer, fileName, onProgress) {
    layerCounter = 0;
    if (!window.agPsd?.readPsd) {
      throw new Error("PSD parser not loaded. Rebuild the plugin and reload.");
    }
    onProgress?.("Reading PSD structure", 0, 1);
    const psd = window.agPsd.readPsd(buffer, {
      skipThumbnail: true,
      skipLinkedFilesData: false,
      logMissingFeatures: false
    });
    const children = psd.children ?? [];
    const total = countLayers(children);
    let current = 0;
    const track = (message) => {
      current += 1;
      onProgress?.(message, current, total);
    };
    const layers = [];
    for (const child of children) {
      layers.push(await convertLayer(child, track));
    }
    return {
      name: fileName.replace(/\.(psd|psb)$/i, ""),
      width: psd.width,
      height: psd.height,
      layers
    };
  }
  function countLayers(layers) {
    let count = 0;
    for (const layer of layers) {
      count += 1;
      if (layer.children?.length) count += countLayers(layer.children);
    }
    return Math.max(count, 1);
  }

  // src/ui.ts
  var dropZone = document.getElementById("drop-zone");
  var fileInput = document.getElementById("file-input");
  var browseBtn = document.getElementById("browse-btn");
  var cancelBtn = document.getElementById("cancel-btn");
  var closeBtn = document.getElementById("close-btn");
  var progressSection = document.getElementById("progress-section");
  var progressBar = document.getElementById("progress-bar");
  var progressLabel = document.getElementById("progress-label");
  var statusText = document.getElementById("status-text");
  var resultSection = document.getElementById("result-section");
  var resultMessage = document.getElementById("result-message");
  var warningsList = document.getElementById("warnings-list");
  var uploadSection = document.getElementById("upload-section");
  var isProcessing = false;
  function postToPlugin(message) {
    parent.postMessage({ pluginMessage: message }, "*");
  }
  function setProgress(current, total, stage) {
    const percent = total > 0 ? Math.round(current / total * 100) : 0;
    progressBar.style.width = `${percent}%`;
    progressLabel.textContent = `${percent}%`;
    statusText.textContent = stage;
  }
  function showUpload() {
    uploadSection.hidden = false;
    progressSection.hidden = true;
    resultSection.hidden = true;
    isProcessing = false;
  }
  function showProgress() {
    uploadSection.hidden = true;
    progressSection.hidden = false;
    resultSection.hidden = true;
    setProgress(0, 100, "Preparing...");
  }
  function showResult(message, warnings) {
    uploadSection.hidden = true;
    progressSection.hidden = true;
    resultSection.hidden = false;
    resultMessage.textContent = message;
    warningsList.innerHTML = "";
    if (warnings.length) {
      for (const warning of warnings) {
        const li = document.createElement("li");
        li.textContent = warning;
        warningsList.appendChild(li);
      }
    } else {
      const li = document.createElement("li");
      li.textContent = "No warnings";
      li.className = "muted";
      warningsList.appendChild(li);
    }
    isProcessing = false;
  }
  async function handleFile(file) {
    if (isProcessing) return;
    const ext = file.name.split(".").pop()?.toLowerCase();
    if (ext !== "psd" && ext !== "psb") {
      showResult("Please select a .psd or .psb file.", []);
      return;
    }
    isProcessing = true;
    showProgress();
    try {
      const buffer = await file.arrayBuffer();
      const document2 = await parsePsdFile(buffer, file.name, (stage, current, total) => {
        setProgress(current, total, stage);
        postToPlugin({ type: "import-progress", stage, current, total });
      });
      setProgress(100, 100, "Creating Figma layers...");
      postToPlugin({ type: "import-document", document: document2 });
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to parse PSD/PSB file";
      showResult(`Error: ${message}`, []);
      postToPlugin({ type: "import-error", message });
    }
  }
  browseBtn.addEventListener("click", () => fileInput.click());
  fileInput.addEventListener("change", () => {
    const file = fileInput.files?.[0];
    if (file) void handleFile(file);
    fileInput.value = "";
  });
  cancelBtn.addEventListener("click", () => {
    postToPlugin({ type: "cancel" });
  });
  closeBtn.addEventListener("click", () => {
    showUpload();
  });
  dropZone.addEventListener("dragover", (event) => {
    event.preventDefault();
    dropZone.classList.add("dragover");
  });
  dropZone.addEventListener("dragleave", () => {
    dropZone.classList.remove("dragover");
  });
  dropZone.addEventListener("drop", (event) => {
    event.preventDefault();
    dropZone.classList.remove("dragover");
    const file = event.dataTransfer?.files?.[0];
    if (file) void handleFile(file);
  });
  window.onmessage = (event) => {
    const msg = event.data.pluginMessage;
    if (!msg) return;
    if (msg.type === "import-started") {
      statusText.textContent = "Building Figma document...";
    }
    if (msg.type === "import-done") {
      showResult(`Successfully imported ${msg.layerCount} layers.`, msg.warnings);
    }
    if (msg.type === "import-failed") {
      showResult(`Import failed: ${msg.message}`, []);
    }
  };
})();
