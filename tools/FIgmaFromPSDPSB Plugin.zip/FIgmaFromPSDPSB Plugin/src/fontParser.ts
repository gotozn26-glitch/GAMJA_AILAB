export interface ParsedFont {
  family: string;
  style: string;
}

const STYLE_PATTERNS: Array<[RegExp, string]> = [
  [/bold\s*italic|italic\s*bold/i, 'Bold Italic'],
  [/\bextra\s*bold\b|\bextrabold\b/i, 'Extra Bold'],
  [/\bextra\s*light\b|\bextralight\b/i, 'Extra Light'],
  [/\bsemi\s*bold\b|\bsemibold\b/i, 'Semi Bold'],
  [/\bbold\b/i, 'Bold'],
  [/\bitalic\b|\boblique\b/i, 'Italic'],
  [/\bmedium\b/i, 'Medium'],
  [/\blight\b/i, 'Light'],
  [/\bregular\b|\bnormal\b|\bbook\b/i, 'Regular'],
  [/\bthin\b/i, 'Thin'],
  [/\bblack\b|\bheavy\b/i, 'Black'],
];

const STYLE_ALIASES: Record<string, string[]> = {
  Regular: ['Regular', 'Normal', 'Book'],
  Medium: ['Medium', 'Med'],
  'Semi Bold': ['Semi Bold', 'SemiBold', 'Demi Bold', 'DemiBold'],
  Bold: ['Bold', 'Bd'],
  'Extra Bold': ['Extra Bold', 'ExtraBold'],
  Light: ['Light', 'Lt'],
  'Extra Light': ['Extra Light', 'ExtraLight'],
  Thin: ['Thin'],
  Black: ['Black', 'Heavy'],
  Italic: ['Italic', 'Oblique'],
  'Bold Italic': ['Bold Italic', 'BoldItalic'],
};

export function normalizeFamilyName(family: string): string {
  return family
    .replace(/\bvariable\b/gi, '')
    .replace(/\bvf\b/gi, '')
    .replace(/\s+/g, ' ')
    .trim();
}

export function parsePsdFontName(fontName?: string): ParsedFont {
  if (!fontName) return { family: 'Inter', style: 'Regular' };

  let family = fontName
    .replace(/[-_]/g, ' ')
    .replace(/\bMT\b/gi, '')
    .replace(/\bPS\b/gi, '')
    .replace(/\bStd\b/gi, '')
    .trim();

  let style = 'Regular';
  for (const [pattern, matchedStyle] of STYLE_PATTERNS) {
    if (pattern.test(family)) {
      style = matchedStyle;
      family = family.replace(pattern, '').trim();
      break;
    }
  }

  family = normalizeFamilyName(family);
  if (!family) family = 'Inter';
  return { family, style };
}

export function applyFauxStyle(
  style: string,
  fauxBold?: boolean,
  fauxItalic?: boolean,
): string {
  if (fauxBold && fauxItalic) return 'Bold Italic';
  if (fauxBold && style === 'Regular') return 'Bold';
  if (fauxItalic && style === 'Regular') return 'Italic';
  if (fauxItalic && style === 'Bold') return 'Bold Italic';
  return style;
}

export function buildFontCandidates(family: string, style: string): FontName[] {
  const originalFamily = family.trim();
  const normalizedFamily = normalizeFamilyName(family);
  const styles = STYLE_ALIASES[style] ?? [style, 'Regular'];
  const families = Array.from(
    new Set(
      [
        originalFamily,
        normalizedFamily,
        normalizedFamily ? `${normalizedFamily} Variable` : '',
        normalizedFamily ? `${normalizedFamily} VF` : '',
      ].filter(Boolean),
    ),
  );
  const candidates: FontName[] = [];

  for (const familyName of families) {
    for (const styleName of styles) {
      candidates.push({ family: familyName, style: styleName });
    }
  }

  for (const familyName of families) {
    candidates.push({ family: familyName, style: 'Regular' });
  }
  return candidates;
}

export function getTextScale(transform: number[]): number {
  const [a = 1, b = 0, , d = 1] = transform;
  const scaleX = Math.hypot(a, b);
  const scaleY = Math.abs(d) || scaleX;
  if (scaleX <= 0) return scaleY || 1;
  return scaleX;
}

export function scaledFontSize(fontSize: number, transform: number[], horizontalScale = 1): number {
  return fontSize * getTextScale(transform) * horizontalScale;
}
