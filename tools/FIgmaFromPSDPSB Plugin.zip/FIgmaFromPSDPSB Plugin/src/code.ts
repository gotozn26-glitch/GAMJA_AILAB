import { buildFigmaDocument } from './figmaBuilder';
import type { ImportDocument, MainToUiMessage, UiToMainMessage } from './types';

figma.showUI(__html__, { width: 420, height: 580, themeColors: true });

figma.ui.onmessage = async (msg: UiToMainMessage) => {
  if (msg.type === 'cancel') {
    figma.closePlugin();
    return;
  }

  if (msg.type === 'import-document') {
    try {
      postToUi({ type: 'import-started' });
      const result = await buildFigmaDocument(msg.document);
      postToUi({
        type: 'import-done',
        layerCount: result.layerCount,
        warnings: result.warnings,
      });
      figma.notify(`Imported ${result.layerCount} layers from ${msg.document.name}`);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unknown import error';
      postToUi({ type: 'import-failed', message });
      figma.notify(`Import failed: ${message}`, { error: true });
    }
    return;
  }

  if (msg.type === 'import-complete') {
    // UI-side completion signal — no action needed
    return;
  }
};

function postToUi(message: MainToUiMessage): void {
  figma.ui.postMessage(message);
}
