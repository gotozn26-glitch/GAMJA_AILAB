import {
  applyFauxStyle,
  buildFontCandidates,
  normalizeFamilyName,
  parsePsdFontName,
} from './fontParser';

const BLEND_MODE_MAP: Record<string, BlendMode> = {
  normal: 'NORMAL',
  pass: 'PASS_THROUGH',
  dissolve: 'NORMAL',
  darken: 'DARKEN',
  multiply: 'MULTIPLY',
  colorburn: 'COLOR_BURN',
  linearburn: 'LINEAR_BURN',
  darkercolor: 'DARKEN',
  lighten: 'LIGHTEN',
  screen: 'SCREEN',
  colordodge: 'COLOR_DODGE',
  lineardodge: 'LINEAR_DODGE',
  lightercolor: 'LIGHTEN',
  overlay: 'OVERLAY',
  softlight: 'SOFT_LIGHT',
  hardlight: 'HARD_LIGHT',
  vividlight: 'OVERLAY',
  linearlight: 'OVERLAY',
  pinlight: 'OVERLAY',
  hardmix: 'OVERLAY',
  difference: 'DIFFERENCE',
  exclusion: 'EXCLUSION',
  subtract: 'EXCLUSION',
  divide: 'EXCLUSION',
  hue: 'HUE',
  saturation: 'SATURATION',
  color: 'COLOR',
  luminosity: 'LUMINOSITY',
};

export function mapBlendMode(psdBlendMode?: string): BlendMode {
  if (!psdBlendMode) return 'NORMAL';
  const key = psdBlendMode.replace(/\s+/g, '').toLowerCase();
  return BLEND_MODE_MAP[key] ?? 'NORMAL';
}

export function psdColorToFigma(color?: { r: number; g: number; b: number }): RGB {
  if (!color) return { r: 0, g: 0, b: 0 };
  return {
    r: color.r / 255,
    g: color.g / 255,
    b: color.b / 255,
  };
}

export function psdOpacityToFigma(opacity?: number): number {
  if (opacity === undefined || opacity === null) return 1;
  return Math.max(0, Math.min(1, opacity));
}

export function solidPaint(color: { r: number; g: number; b: number }, opacity = 1): SolidPaint {
  return {
    type: 'SOLID',
    color: psdColorToFigma(color),
    opacity: psdOpacityToFigma(opacity),
  };
}

export function mapTextAlign(justification?: string): 'LEFT' | 'CENTER' | 'RIGHT' | 'JUSTIFIED' {
  switch (justification) {
    case 'center':
      return 'CENTER';
    case 'right':
      return 'RIGHT';
    case 'justifyAll':
    case 'justifyLeft':
    case 'justifyCenter':
    case 'justifyRight':
      return 'JUSTIFIED';
    default:
      return 'LEFT';
  }
}

export function parseFontFamily(fontName?: string): { family: string; style: string } {
  return parsePsdFontName(fontName);
}

export function mapTextCase(fontCaps?: number): 'ORIGINAL' | 'UPPER' | 'LOWER' | 'TITLE' {
  switch (fontCaps) {
    case 2:
      return 'UPPER';
    default:
      return 'ORIGINAL';
  }
}

let availableFontsPromise: Promise<FontName[]> | null = null;

function normalizeStyleName(style: string): string {
  return style.toLowerCase().replace(/[\s_-]+/g, '');
}

async function getAvailableFonts(): Promise<FontName[]> {
  if (!availableFontsPromise) {
    availableFontsPromise = figma
      .listAvailableFontsAsync()
      .then((fonts) => fonts.map((font) => font.fontName));
  }
  return availableFontsPromise;
}

async function resolveAvailableFont(family: string, style: string): Promise<FontName | null> {
  const candidates = buildFontCandidates(family, style);
  const availableFonts = await getAvailableFonts();

  for (const candidate of candidates) {
    const match = availableFonts.find(
      (font) =>
        font.family.toLowerCase() === candidate.family.toLowerCase() &&
        font.style.toLowerCase() === candidate.style.toLowerCase(),
    );
    if (match) return match;
  }

  for (const candidate of candidates) {
    const candidateFamily = normalizeFamilyName(candidate.family).toLowerCase();
    const candidateStyle = normalizeStyleName(candidate.style);
    const match = availableFonts.find(
      (font) =>
        normalizeFamilyName(font.family).toLowerCase() === candidateFamily &&
        normalizeStyleName(font.style) === candidateStyle,
    );
    if (match) return match;
  }

  return null;
}

export async function tryLoadFont(family: string, style: string): Promise<FontName | null> {
  const font = await resolveAvailableFont(family, style);
  if (!font) return null;

  try {
    await figma.loadFontAsync(font);
    return font;
  } catch {
    return null;
  }
}

export async function isExactFontAvailable(family: string, style: string): Promise<boolean> {
  const loaded = await tryLoadFont(family, style);
  if (!loaded) return false;
  return normalizeFamilyName(loaded.family).toLowerCase() === normalizeFamilyName(family).toLowerCase();
}

export async function canLoadFont(family: string, style: string): Promise<boolean> {
  return isExactFontAvailable(family, style);
}

export async function loadFontWithFallback(family: string, style: string): Promise<FontName> {
  const loaded = await tryLoadFont(family, style);
  if (loaded) return loaded;

  const fallbacks: FontName[] = [
    { family: 'Inter', style: 'Regular' },
    { family: 'Roboto', style: 'Regular' },
    { family: 'Arial', style: 'Regular' },
  ];

  for (const font of fallbacks) {
    try {
      await figma.loadFontAsync(font);
      return font;
    } catch {
      // try next candidate
    }
  }

  throw new Error(`No available font for ${family} ${style}`);
}

export function applyDropShadow(node: SceneNode, shadow: import('./types').DropShadowEffect): void {
  if (!('effects' in node)) return;

  const existing = [...(node.effects as readonly Effect[])];
  existing.push({
    type: 'DROP_SHADOW',
    color: {
      ...psdColorToFigma(shadow.color),
      a: psdOpacityToFigma(shadow.opacity),
    },
    offset: { x: shadow.offsetX, y: shadow.offsetY },
    radius: shadow.blur,
    spread: shadow.spread,
    visible: true,
    blendMode: 'NORMAL',
  });
  node.effects = existing;
}

export function applyInnerShadow(node: SceneNode, shadow: import('./types').DropShadowEffect): void {
  if (!('effects' in node)) return;

  const existing = [...(node.effects as readonly Effect[])];
  existing.push({
    type: 'INNER_SHADOW',
    color: {
      ...psdColorToFigma(shadow.color),
      a: psdOpacityToFigma(shadow.opacity),
    },
    offset: { x: shadow.offsetX, y: shadow.offsetY },
    radius: shadow.blur,
    spread: shadow.spread,
    visible: true,
    blendMode: 'NORMAL',
  });
  node.effects = existing;
}

export { applyFauxStyle, scaledFontSize } from './fontParser';
