import type {
  DropShadowEffect,
  FillData,
  ImportDocument,
  ImportLayer,
  LayerEffectsData,
  StrokeData,
  TextData,
  TextStyleRun,
  VectorPathData,
} from './types';
import { applyFauxStyle, parsePsdFontName } from './fontParser';

interface AgPsdLayer {
  name?: string;
  left?: number;
  top?: number;
  right?: number;
  bottom?: number;
  opacity?: number;
  hidden?: boolean;
  blendMode?: string;
  clipping?: boolean;
  children?: AgPsdLayer[];
  text?: AgPsdText;
  adjustment?: unknown;
  placedLayer?: unknown;
  vectorMask?: AgPsdVectorMask;
  vectorFill?: AgPsdVectorFill;
  vectorStroke?: AgPsdVectorStroke;
  solidColor?: { r: number; g: number; b: number };
  canvas?: HTMLCanvasElement;
  mask?: { fromVectorData?: boolean };
  effects?: AgPsdEffects;
  artboard?: {
    rect: {
      top: number;
      left: number;
      bottom: number;
      right: number;
    };
  };
}

interface AgPsdText {
  text?: string;
  transform?: number[];
  bounds?: {
    left?: { value: number };
    top?: { value: number };
    right?: { value: number };
    bottom?: { value: number };
  };
  style?: AgPsdTextStyle;
  paragraphStyle?: { justification?: string };
  styleRuns?: Array<{ length: number; style?: AgPsdTextStyle }>;
}

interface AgPsdTextStyle {
  font?: { name?: string };
  fontSize?: number;
  fillColor?: { r: number; g: number; b: number };
  leading?: number;
  tracking?: number;
  fontCaps?: number;
  underline?: boolean;
  strikethrough?: boolean;
  fauxBold?: boolean;
  fauxItalic?: boolean;
  horizontalScale?: number;
}

interface AgPsdVectorMask {
  paths: Array<{
    open: boolean;
    operation?: string;
    knots: Array<{ points: number[] }>;
  }>;
}

interface AgPsdVectorFill {
  type?: string;
  color?: { r: number; g: number; b: number };
  opacity?: number;
}

interface AgPsdVectorStroke {
  fillEnabled?: boolean;
  content?: { color?: { r: number; g: number; b: number } };
  lineWidth?: number | { value: number };
  lineAlignment?: string;
  opacity?: number;
  lineDashSet?: Array<{ value: number }>;
}

interface AgPsdEffects {
  dropShadow?: AgPsdShadow[];
  innerShadow?: AgPsdShadow[];
}

interface AgPsdShadow {
  enabled?: boolean;
  color?: { r: number; g: number; b: number };
  opacity?: number;
  angle?: number;
  distance?: { value: number };
  size?: { value: number };
  choke?: { value: number };
}

interface AgPsdDocument {
  width: number;
  height: number;
  children?: AgPsdLayer[];
}

declare global {
  interface Window {
    agPsd: {
      readPsd: (buffer: ArrayBuffer, options?: Record<string, unknown>) => AgPsdDocument;
    };
  }
}

let layerCounter = 0;

function nextId(): string {
  layerCounter += 1;
  return `layer-${layerCounter}`;
}

function layerBounds(layer: AgPsdLayer): { left: number; top: number; width: number; height: number } {
  if (layer.artboard?.rect) {
    const { left, top, right, bottom } = layer.artboard.rect;
    return {
      left,
      top,
      width: Math.max(1, right - left),
      height: Math.max(1, bottom - top),
    };
  }

  const left = layer.left ?? 0;
  const top = layer.top ?? 0;
  const right = layer.right ?? left;
  const bottom = layer.bottom ?? top;
  return {
    left,
    top,
    width: Math.max(1, right - left),
    height: Math.max(1, bottom - top),
  };
}

function unionChildBounds(
  layers: ImportLayer[],
): { left: number; top: number; width: number; height: number } | null {
  if (!layers.length) return null;

  let left = layers[0].left;
  let top = layers[0].top;
  let right = layers[0].left + layers[0].width;
  let bottom = layers[0].top + layers[0].height;

  for (let i = 1; i < layers.length; i += 1) {
    const layer = layers[i];
    left = Math.min(left, layer.left);
    top = Math.min(top, layer.top);
    right = Math.max(right, layer.left + layer.width);
    bottom = Math.max(bottom, layer.top + layer.height);
  }

  return {
    left,
    top,
    width: Math.max(1, right - left),
    height: Math.max(1, bottom - top),
  };
}

const FIGMA_MAX_IMAGE_SIZE = 4096;

function scaleCanvasForFigma(canvas: HTMLCanvasElement): { canvas: HTMLCanvasElement; note?: string } {
  const width = canvas.width;
  const height = canvas.height;

  if (width <= FIGMA_MAX_IMAGE_SIZE && height <= FIGMA_MAX_IMAGE_SIZE) {
    return { canvas };
  }

  const scale = Math.min(FIGMA_MAX_IMAGE_SIZE / width, FIGMA_MAX_IMAGE_SIZE / height);
  const scaled = document.createElement('canvas');
  scaled.width = Math.max(1, Math.floor(width * scale));
  scaled.height = Math.max(1, Math.floor(height * scale));

  const ctx = scaled.getContext('2d');
  if (!ctx) return { canvas };

  ctx.drawImage(canvas, 0, 0, scaled.width, scaled.height);
  return {
    canvas: scaled,
    note: `Scaled image from ${width}x${height} to ${scaled.width}x${scaled.height} (Figma 4096px limit)`,
  };
}

async function canvasToPngBytes(
  canvas: HTMLCanvasElement,
): Promise<{ bytes: number[]; scaleNote?: string; sourceWidth: number; sourceHeight: number }> {
  const sourceWidth = canvas.width;
  const sourceHeight = canvas.height;
  const { canvas: exportCanvas, note } = scaleCanvasForFigma(canvas);

  const bytes = await new Promise<number[]>((resolve, reject) => {
    exportCanvas.toBlob((blob) => {
      if (!blob) {
        reject(new Error('Failed to encode layer image'));
        return;
      }
      blob.arrayBuffer().then((buffer) => resolve(Array.from(new Uint8Array(buffer))));
    }, 'image/png');
  });

  return { bytes, scaleNote: note, sourceWidth, sourceHeight };
}

function convertFill(layer: AgPsdLayer): FillData | undefined {
  if (layer.vectorFill?.color) {
    return {
      type: 'solid',
      color: {
        r: layer.vectorFill.color.r,
        g: layer.vectorFill.color.g,
        b: layer.vectorFill.color.b,
      },
      opacity: layer.vectorFill.opacity ?? 1,
    };
  }

  if (layer.solidColor) {
    return {
      type: 'solid',
      color: {
        r: layer.solidColor.r,
        g: layer.solidColor.g,
        b: layer.solidColor.b,
      },
      opacity: layer.opacity ?? 1,
    };
  }

  return undefined;
}

function convertStroke(layer: AgPsdLayer): StrokeData | undefined {
  const stroke = layer.vectorStroke;
  if (!stroke || stroke.fillEnabled === false) return undefined;

  const color = stroke.content?.color;
  if (!color) return undefined;

  let align: StrokeData['align'] = 'center';
  if (stroke.lineAlignment === 'inside') align = 'inside';
  if (stroke.lineAlignment === 'outside') align = 'outside';

  const lineWidth =
    typeof stroke.lineWidth === 'object' && stroke.lineWidth !== null
      ? stroke.lineWidth.value
      : stroke.lineWidth ?? 1;

  return {
    color: { r: color.r, g: color.g, b: color.b },
    weight: lineWidth,
    opacity: stroke.opacity ?? 1,
    align,
    dashPattern: stroke.lineDashSet?.map((d) => d.value),
  };
}

function convertVectorPaths(layer: AgPsdLayer): VectorPathData[] | undefined {
  if (!layer.vectorMask?.paths?.length) return undefined;

  return layer.vectorMask.paths.map((path) => ({
    windingRule: path.operation === 'exclude' ? 'EVENODD' : 'NONZERO',
    data: bezierPathToSvg(path.knots, path.open),
  }));
}

function bezierPathToSvg(knots: Array<{ points: number[] }>, open: boolean): string {
  if (!knots.length) return '';

  const parts: string[] = [];
  const first = knots[0].points;
  parts.push(`M ${first[2]} ${first[3]}`);

  for (let i = 0; i < knots.length; i++) {
    const current = knots[i].points;
    const next = knots[(i + 1) % knots.length].points;
    if (open && i === knots.length - 1) break;
    parts.push(`C ${current[4]} ${current[5]} ${next[0]} ${next[1]} ${next[2]} ${next[3]}`);
  }

  if (!open) parts.push('Z');
  return parts.join(' ');
}

function resolveFontStyle(fontName: string | undefined, style: AgPsdTextStyle): { family: string; style: string } {
  const parsed = parsePsdFontName(fontName);
  return {
    family: parsed.family,
    style: applyFauxStyle(parsed.style, style.fauxBold, style.fauxItalic),
  };
}

function mapJustification(justification?: string): TextData['textAlign'] {
  switch (justification) {
    case 'center':
      return 'center';
    case 'right':
      return 'right';
    case 'justifyAll':
    case 'justifyLeft':
    case 'justifyCenter':
    case 'justifyRight':
      return 'justify';
    default:
      return 'left';
  }
}

function convertText(layer: AgPsdLayer): TextData | undefined {
  const textData = layer.text;
  if (!textData) return undefined;

  const style = textData.style ?? {};
  const paragraphStyle = textData.paragraphStyle ?? {};
  const fontInfo = resolveFontStyle(style.font?.name, style);
  const transform = textData.transform ?? [1, 0, 0, 1, 0, 0];

  const styleRuns: TextStyleRun[] = [];
  if (textData.styleRuns?.length) {
    let offset = 0;
    for (const run of textData.styleRuns) {
      const runStyle = run.style ?? {};
      const runFont = resolveFontStyle(runStyle.font?.name ?? style.font?.name, runStyle);
      styleRuns.push({
        start: offset,
        end: offset + run.length,
        fontFamily: runFont.family,
        fontStyle: runFont.style,
        fontSize: runStyle.fontSize ?? style.fontSize ?? 16,
        fillColor: runStyle.fillColor
          ? { r: runStyle.fillColor.r, g: runStyle.fillColor.g, b: runStyle.fillColor.b }
          : style.fillColor
            ? { r: style.fillColor.r, g: style.fillColor.g, b: style.fillColor.b }
            : undefined,
        fauxBold: runStyle.fauxBold,
        fauxItalic: runStyle.fauxItalic,
        underline: runStyle.underline,
        strikethrough: runStyle.strikethrough,
        letterSpacing: runStyle.tracking
          ? (runStyle.tracking / 1000) * (runStyle.fontSize ?? style.fontSize ?? 16)
          : undefined,
      });
      offset += run.length;
    }
  }

  const fillColor = style.fillColor
    ? { r: style.fillColor.r, g: style.fillColor.g, b: style.fillColor.b }
    : { r: 0, g: 0, b: 0 };

  return {
    content: textData.text ?? '',
    fontFamily: fontInfo.family,
    fontStyle: fontInfo.style,
    fontSize: style.fontSize ?? 16,
    fillColor,
    lineHeight: style.leading && style.fontSize ? style.leading / style.fontSize : undefined,
    letterSpacing: style.tracking ? (style.tracking / 1000) * (style.fontSize ?? 16) : undefined,
    textAlign: mapJustification(paragraphStyle.justification),
    textCase: style.fontCaps === 2 ? 'UPPER' : 'ORIGINAL',
    textDecoration: style.underline ? 'UNDERLINE' : style.strikethrough ? 'STRIKETHROUGH' : 'NONE',
    transform,
    horizontalScale: style.horizontalScale ?? 1,
    boxWidth:
      textData.bounds?.right?.value !== undefined && textData.bounds?.left?.value !== undefined
        ? textData.bounds.right.value - textData.bounds.left.value
        : undefined,
    boxHeight:
      textData.bounds?.bottom?.value !== undefined && textData.bounds?.top?.value !== undefined
        ? textData.bounds.bottom.value - textData.bounds.top.value
        : undefined,
    styleRuns: styleRuns.length ? styleRuns : undefined,
  };
}

function shadowFromPsd(shadow: AgPsdShadow): DropShadowEffect {
  const angleRad = ((shadow.angle ?? 120) * Math.PI) / 180;
  const distance = shadow.distance?.value ?? 0;
  return {
    color: shadow.color ?? { r: 0, g: 0, b: 0 },
    opacity: shadow.opacity ?? 0.75,
    offsetX: Math.round(Math.cos(angleRad) * distance),
    offsetY: Math.round(Math.sin(angleRad) * distance),
    blur: shadow.size?.value ?? 0,
    spread: shadow.choke?.value ?? 0,
  };
}

function convertEffects(layer: AgPsdLayer): LayerEffectsData | undefined {
  const effects = layer.effects;
  if (!effects) return undefined;

  const result: LayerEffectsData = {};

  if (effects.dropShadow?.length) {
    result.dropShadow = effects.dropShadow
      .filter((s) => s.enabled !== false)
      .map((s) => shadowFromPsd(s));
  }

  if (effects.innerShadow?.length) {
    result.innerShadow = effects.innerShadow
      .filter((s) => s.enabled !== false)
      .map((s) => shadowFromPsd(s));
  }

  return result.dropShadow?.length || result.innerShadow?.length ? result : undefined;
}

function detectLayerKind(layer: AgPsdLayer): ImportLayer['kind'] {
  if (layer.children?.length) return 'group';
  if (layer.text) return 'text';
  if (layer.adjustment) return 'adjustment';
  if (layer.placedLayer) return 'smartObject';
  if (layer.vectorMask && (layer.vectorFill || layer.vectorStroke)) return 'vector';
  if (layer.vectorMask) return 'vector';
  return 'image';
}

async function convertLayer(
  layer: AgPsdLayer,
  onProgress?: (message: string) => void,
): Promise<ImportLayer> {
  const bounds = layerBounds(layer);
  const kind = detectLayerKind(layer);
  const id = nextId();

  onProgress?.(`Converting: ${layer.name ?? id}`);

  const importLayer: ImportLayer = {
    id,
    name: layer.name ?? 'Layer',
    kind,
    isArtboard: !!layer.artboard,
    left: bounds.left,
    top: bounds.top,
    width: bounds.width,
    height: bounds.height,
    opacity: layer.opacity ?? 1,
    visible: !layer.hidden,
    blendMode: layer.blendMode ?? 'normal',
    clipped: !!layer.clipping,
    fill: convertFill(layer),
    stroke: convertStroke(layer),
    vectorPaths: convertVectorPaths(layer),
    text: kind === 'text' ? convertText(layer) : undefined,
    effects: convertEffects(layer),
    isMask: !!layer.mask,
    maskFromVector: layer.mask?.fromVectorData,
  };

  if (kind === 'group' && layer.children?.length) {
    importLayer.children = [];
    for (const child of layer.children) {
      importLayer.children.push(await convertLayer(child, onProgress));
    }

    if (!importLayer.isArtboard) {
      const childBounds = unionChildBounds(importLayer.children);
      if (childBounds) {
        importLayer.left = childBounds.left;
        importLayer.top = childBounds.top;
        importLayer.width = childBounds.width;
        importLayer.height = childBounds.height;
      }
    }
  } else if (layer.canvas && kind !== 'text' && kind !== 'vector') {
    try {
      const encoded = await canvasToPngBytes(layer.canvas);
      importLayer.imageBytes = encoded.bytes;
      importLayer.imageWidth = encoded.sourceWidth;
      importLayer.imageHeight = encoded.sourceHeight;
      importLayer.imageFormat = 'png';
      importLayer.imageScaleNote = encoded.scaleNote;
    } catch {
      // keep as empty layer if rasterization fails
    }
  } else if (kind === 'vector' && layer.canvas && !importLayer.vectorPaths?.length) {
    try {
      const encoded = await canvasToPngBytes(layer.canvas);
      importLayer.imageBytes = encoded.bytes;
      importLayer.imageWidth = encoded.sourceWidth;
      importLayer.imageHeight = encoded.sourceHeight;
      importLayer.imageFormat = 'png';
      importLayer.imageScaleNote = encoded.scaleNote;
      importLayer.kind = 'image';
    } catch {
      // ignore
    }
  }

  if (kind === 'text' && layer.canvas) {
    try {
      const encoded = await canvasToPngBytes(layer.canvas);
      importLayer.textRasterBytes = encoded.bytes;
      importLayer.textRasterWidth = encoded.sourceWidth;
      importLayer.textRasterHeight = encoded.sourceHeight;
      importLayer.textRasterScaleNote = encoded.scaleNote;
    } catch {
      // text may still import as editable if raster preview is unavailable
    }
  }

  return importLayer;
}

export async function parsePsdFile(
  buffer: ArrayBuffer,
  fileName: string,
  onProgress?: (stage: string, current: number, total: number) => void,
): Promise<ImportDocument> {
  layerCounter = 0;

  if (!window.agPsd?.readPsd) {
    throw new Error('PSD parser not loaded. Rebuild the plugin and reload.');
  }

  onProgress?.('Reading PSD structure', 0, 1);

  const psd = window.agPsd.readPsd(buffer, {
    skipThumbnail: true,
    skipLinkedFilesData: false,
    logMissingFeatures: false,
  });

  const children = psd.children ?? [];
  const total = countLayers(children);
  let current = 0;

  const track = (message: string) => {
    current += 1;
    onProgress?.(message, current, total);
  };

  const layers: ImportLayer[] = [];
  for (const child of children) {
    layers.push(await convertLayer(child, track));
  }

  return {
    name: fileName.replace(/\.(psd|psb)$/i, ''),
    width: psd.width,
    height: psd.height,
    layers,
  };
}

function countLayers(layers: AgPsdLayer[]): number {
  let count = 0;
  for (const layer of layers) {
    count += 1;
    if (layer.children?.length) count += countLayers(layer.children);
  }
  return Math.max(count, 1);
}
