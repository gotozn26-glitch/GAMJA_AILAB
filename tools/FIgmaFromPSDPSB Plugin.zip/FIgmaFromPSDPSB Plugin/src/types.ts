export type LayerKind = 'group' | 'text' | 'vector' | 'image' | 'smartObject' | 'adjustment';

export interface RGBColor {
  r: number;
  g: number;
  b: number;
  a?: number;
}

export interface SolidFill {
  type: 'solid';
  color: RGBColor;
  opacity: number;
}

export interface GradientStop {
  color: RGBColor;
  position: number;
}

export interface GradientFill {
  type: 'gradient';
  gradientType: 'linear' | 'radial';
  angle: number;
  stops: GradientStop[];
  opacity: number;
}

export type FillData = SolidFill | GradientFill;

export interface StrokeData {
  color: RGBColor;
  weight: number;
  opacity: number;
  align: 'inside' | 'center' | 'outside';
  dashPattern?: number[];
}

export interface TextStyleRun {
  start: number;
  end: number;
  fontFamily: string;
  fontStyle: string;
  fontSize: number;
  fillColor?: RGBColor;
  fauxBold?: boolean;
  fauxItalic?: boolean;
  underline?: boolean;
  strikethrough?: boolean;
  letterSpacing?: number;
}

export interface TextData {
  content: string;
  fontFamily: string;
  fontStyle: string;
  fontSize: number;
  fillColor: RGBColor;
  lineHeight?: number;
  letterSpacing?: number;
  textAlign: 'left' | 'center' | 'right' | 'justify';
  textCase?: 'ORIGINAL' | 'UPPER' | 'LOWER' | 'TITLE';
  textDecoration?: 'NONE' | 'UNDERLINE' | 'STRIKETHROUGH';
  transform: number[];
  horizontalScale?: number;
  boxWidth?: number;
  boxHeight?: number;
  styleRuns?: TextStyleRun[];
}

export interface VectorPathData {
  windingRule: 'NONZERO' | 'EVENODD';
  data: string;
}

export interface DropShadowEffect {
  color: RGBColor;
  opacity: number;
  offsetX: number;
  offsetY: number;
  blur: number;
  spread: number;
}

export interface LayerEffectsData {
  dropShadow?: DropShadowEffect[];
  innerShadow?: DropShadowEffect[];
}

export interface ImportLayer {
  id: string;
  name: string;
  kind: LayerKind;
  isArtboard?: boolean;
  left: number;
  top: number;
  width: number;
  height: number;
  opacity: number;
  visible: boolean;
  blendMode: string;
  clipped: boolean;
  children?: ImportLayer[];
  text?: TextData;
  textRasterBytes?: number[];
  textRasterWidth?: number;
  textRasterHeight?: number;
  textRasterScaleNote?: string;
  vectorPaths?: VectorPathData[];
  fill?: FillData;
  stroke?: StrokeData;
  imageBytes?: number[];
  imageWidth?: number;
  imageHeight?: number;
  imageFormat?: 'png';
  imageScaleNote?: string;
  effects?: LayerEffectsData;
  isMask?: boolean;
  maskFromVector?: boolean;
}

export interface ImportOptions {
  /** When true, use PSD text bitmap if Figma fonts are unavailable (default: true) */
  rasterizeTextIfFontMissing: boolean;
  /** When true, import all text layers as raster images for pixel-perfect match */
  rasterizeAllText: boolean;
}

export interface ImportDocument {
  name: string;
  width: number;
  height: number;
  layers: ImportLayer[];
  options?: ImportOptions;
}

export type UiToMainMessage =
  | { type: 'import-document'; document: ImportDocument }
  | { type: 'import-progress'; stage: string; current: number; total: number }
  | { type: 'import-error'; message: string }
  | { type: 'import-complete'; layerCount: number; warnings: string[] }
  | { type: 'cancel' };

export type MainToUiMessage =
  | { type: 'import-started' }
  | { type: 'import-done'; layerCount: number; warnings: string[] }
  | { type: 'import-failed'; message: string };
