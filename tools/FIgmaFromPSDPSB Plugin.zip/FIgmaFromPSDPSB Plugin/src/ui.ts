import { parsePsdFile } from './psdParser';
import type { MainToUiMessage, UiToMainMessage } from './types';

const dropZone = document.getElementById('drop-zone') as HTMLDivElement;
const fileInput = document.getElementById('file-input') as HTMLInputElement;
const browseBtn = document.getElementById('browse-btn') as HTMLButtonElement;
const cancelBtn = document.getElementById('cancel-btn') as HTMLButtonElement;
const closeBtn = document.getElementById('close-btn') as HTMLButtonElement;
const progressSection = document.getElementById('progress-section') as HTMLDivElement;
const progressBar = document.getElementById('progress-bar') as HTMLDivElement;
const progressLabel = document.getElementById('progress-label') as HTMLParagraphElement;
const statusText = document.getElementById('status-text') as HTMLParagraphElement;
const resultSection = document.getElementById('result-section') as HTMLDivElement;
const resultMessage = document.getElementById('result-message') as HTMLParagraphElement;
const warningsList = document.getElementById('warnings-list') as HTMLUListElement;
const uploadSection = document.getElementById('upload-section') as HTMLDivElement;
const rasterizeMissingFont = document.getElementById('rasterize-missing-font') as HTMLInputElement;
const rasterizeAllText = document.getElementById('rasterize-all-text') as HTMLInputElement;

let isProcessing = false;

function postToPlugin(message: UiToMainMessage): void {
  parent.postMessage({ pluginMessage: message }, '*');
}

function setProgress(current: number, total: number, stage: string): void {
  const percent = total > 0 ? Math.round((current / total) * 100) : 0;
  progressBar.style.width = `${percent}%`;
  progressLabel.textContent = `${percent}%`;
  statusText.textContent = stage;
}

function showUpload(): void {
  uploadSection.hidden = false;
  progressSection.hidden = true;
  resultSection.hidden = true;
  isProcessing = false;
}

function showProgress(): void {
  uploadSection.hidden = true;
  progressSection.hidden = false;
  resultSection.hidden = true;
  setProgress(0, 100, 'Preparing...');
}

function showResult(message: string, warnings: string[]): void {
  uploadSection.hidden = true;
  progressSection.hidden = true;
  resultSection.hidden = false;
  resultMessage.textContent = message;
  warningsList.innerHTML = '';
  if (warnings.length) {
    for (const warning of warnings) {
      const li = document.createElement('li');
      li.textContent = warning;
      warningsList.appendChild(li);
    }
  } else {
    const li = document.createElement('li');
    li.textContent = 'No warnings';
    li.className = 'muted';
    warningsList.appendChild(li);
  }
  isProcessing = false;
}

async function handleFile(file: File): Promise<void> {
  if (isProcessing) return;

  const ext = file.name.split('.').pop()?.toLowerCase();
  if (ext !== 'psd' && ext !== 'psb') {
    showResult('Please select a .psd or .psb file.', []);
    return;
  }

  isProcessing = true;
  showProgress();

  try {
    const buffer = await file.arrayBuffer();

    const document = await parsePsdFile(buffer, file.name, (stage, current, total) => {
      setProgress(current, total, stage);
      postToPlugin({ type: 'import-progress', stage, current, total });
    });

    setProgress(100, 100, 'Creating Figma layers...');
    postToPlugin({
      type: 'import-document',
      document: {
        ...document,
        options: {
          rasterizeTextIfFontMissing: rasterizeMissingFont.checked,
          rasterizeAllText: rasterizeAllText.checked,
        },
      },
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to parse PSD/PSB file';
    showResult(`Error: ${message}`, []);
    postToPlugin({ type: 'import-error', message });
  }
}

browseBtn.addEventListener('click', () => fileInput.click());

fileInput.addEventListener('change', () => {
  const file = fileInput.files?.[0];
  if (file) void handleFile(file);
  fileInput.value = '';
});

cancelBtn.addEventListener('click', () => {
  postToPlugin({ type: 'cancel' });
});

closeBtn.addEventListener('click', () => {
  showUpload();
});

dropZone.addEventListener('dragover', (event) => {
  event.preventDefault();
  dropZone.classList.add('dragover');
});

dropZone.addEventListener('dragleave', () => {
  dropZone.classList.remove('dragover');
});

dropZone.addEventListener('drop', (event) => {
  event.preventDefault();
  dropZone.classList.remove('dragover');
  const file = event.dataTransfer?.files?.[0];
  if (file) void handleFile(file);
});

window.onmessage = (event: MessageEvent) => {
  const msg = event.data.pluginMessage as MainToUiMessage | undefined;
  if (!msg) return;

  if (msg.type === 'import-started') {
    statusText.textContent = 'Building Figma document...';
  }

  if (msg.type === 'import-done') {
    showResult(`Successfully imported ${msg.layerCount} layers.`, msg.warnings);
  }

  if (msg.type === 'import-failed') {
    showResult(`Import failed: ${msg.message}`, []);
  }
};
