import type { FillData, ImportDocument, ImportLayer, ImportOptions, StrokeData, TextData } from './types';
import {
  applyDropShadow,
  applyInnerShadow,
  isExactFontAvailable,
  mapBlendMode,
  mapTextAlign,
  mapTextCase,
  psdOpacityToFigma,
  scaledFontSize,
  solidPaint,
  tryLoadFont,
} from './figmaMapper';

const DEFAULT_OPTIONS: ImportOptions = {
  rasterizeTextIfFontMissing: true,
  rasterizeAllText: false,
};

const warnings: string[] = [];

function warn(message: string): void {
  warnings.push(message);
}

function resolveOptions(document: ImportDocument): ImportOptions {
  return { ...DEFAULT_OPTIONS, ...document.options };
}

function applyCommonProps(
  node: SceneNode,
  layer: ImportLayer,
  parentX = 0,
  parentY = 0,
  includePosition = true,
): void {
  if ('name' in node) node.name = layer.name;
  if (includePosition && 'x' in node && 'y' in node) {
    node.x = layer.left - parentX;
    node.y = layer.top - parentY;
  }
  if ('opacity' in node) node.opacity = psdOpacityToFigma(layer.opacity);
  if ('visible' in node) node.visible = layer.visible;
  if ('blendMode' in node) node.blendMode = mapBlendMode(layer.blendMode);
}

function applyEffects(node: SceneNode, layer: ImportLayer): void {
  if (layer.effects?.dropShadow) {
    for (const shadow of layer.effects.dropShadow) {
      applyDropShadow(node, shadow);
    }
  }
  if (layer.effects?.innerShadow) {
    for (const shadow of layer.effects.innerShadow) {
      applyInnerShadow(node, shadow);
    }
  }
}

function applyFill(node: GeometryMixin, fill?: FillData): void {
  if (!fill || fill.type !== 'solid') return;
  node.fills = [solidPaint(fill.color, fill.opacity)];
}

function applyStroke(node: GeometryMixin, stroke?: StrokeData): void {
  if (!stroke) return;
  node.strokes = [solidPaint(stroke.color, stroke.opacity)];
  node.strokeWeight = stroke.weight;
  if (stroke.align === 'inside') node.strokeAlign = 'INSIDE';
  else if (stroke.align === 'outside') node.strokeAlign = 'OUTSIDE';
  else node.strokeAlign = 'CENTER';
}

async function createImageNodeFromBytes(
  layer: ImportLayer,
  bytes: number[],
  width: number,
  height: number,
  scaleNote?: string,
  quiet = false,
): Promise<RectangleNode | null> {
  if (!bytes.length) return null;

  const rect = figma.createRectangle();
  rect.resize(Math.max(width, 1), Math.max(height, 1));

  if (scaleNote && !quiet) {
    warn(`${layer.name}: ${scaleNote}`);
  }

  try {
    const image = figma.createImage(new Uint8Array(bytes));
    rect.fills = [
      {
        type: 'IMAGE',
        imageHash: image.hash,
        scaleMode: 'FILL',
      },
    ];
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Invalid image data';
    warn(`Skipped image layer "${layer.name}": ${message}`);
    return null;
  }

  applyEffects(rect, layer);
  return rect;
}

async function createImageNode(layer: ImportLayer): Promise<RectangleNode | null> {
  if (!layer.imageBytes?.length) return null;
  return createImageNodeFromBytes(
    layer,
    layer.imageBytes,
    layer.imageWidth ?? layer.width,
    layer.imageHeight ?? layer.height,
    layer.imageScaleNote,
  );
}

async function createTextRasterNode(layer: ImportLayer): Promise<RectangleNode | null> {
  if (!layer.textRasterBytes?.length) {
    warn(`Text "${layer.name}": no raster preview in PSD`);
    return null;
  }

  const node = await createImageNodeFromBytes(
    layer,
    layer.textRasterBytes,
    layer.textRasterWidth ?? layer.width,
    layer.textRasterHeight ?? layer.height,
    layer.textRasterScaleNote,
    true,
  );
  if (node) {
    warn(`Text "${layer.name}" imported as image (original appearance preserved)`);
  }
  return node;
}

function collectTextFonts(text: TextData): Array<{ family: string; style: string }> {
  return [{ family: text.fontFamily, style: text.fontStyle }];
}

async function areTextFontsAvailable(text: TextData): Promise<boolean> {
  const [primary] = collectTextFonts(text);
  return isExactFontAvailable(primary.family, primary.style);
}

async function createEditableTextNode(layer: ImportLayer): Promise<TextNode | null> {
  if (!layer.text) return null;

  const textNode = figma.createText();
  const text = layer.text;

  const loadedFont = await tryLoadFont(text.fontFamily, text.fontStyle);
  if (loadedFont) {
    textNode.fontName = loadedFont;
  } else {
    warn(`Font not found: ${text.fontFamily} ${text.fontStyle} — using Inter`);
    await figma.loadFontAsync({ family: 'Inter', style: 'Regular' });
    textNode.fontName = { family: 'Inter', style: 'Regular' };
  }

  textNode.characters = text.content;
  textNode.fontSize = scaledFontSize(text.fontSize, text.transform, text.horizontalScale ?? 1);
  textNode.fills = [solidPaint(text.fillColor)];

  if (text.lineHeight) {
    textNode.lineHeight = { unit: 'PERCENT', value: text.lineHeight * 100 };
  }
  if (text.letterSpacing !== undefined) {
    textNode.letterSpacing = { unit: 'PIXELS', value: text.letterSpacing };
  }

  textNode.textAlignHorizontal = mapTextAlign(text.textAlign);
  textNode.textCase = mapTextCase(text.textCase === 'UPPER' ? 2 : 0);

  if (text.textDecoration === 'UNDERLINE') textNode.textDecoration = 'UNDERLINE';
  if (text.textDecoration === 'STRIKETHROUGH') textNode.textDecoration = 'STRIKETHROUGH';

  const [a, b] = text.transform;
  if (Math.abs(a - 1) > 0.001 || Math.abs(b) > 0.001) {
    const angle = Math.atan2(b, a);
    textNode.rotation = (-angle * 180) / Math.PI;
  }

  textNode.textAutoResize = 'WIDTH_AND_HEIGHT';

  if (text.styleRuns?.length) {
    for (const run of text.styleRuns) {
      if (run.start >= text.content.length) continue;
      const end = Math.min(run.end, text.content.length);
      const runSize = scaledFontSize(
        run.fontSize ?? text.fontSize,
        text.transform,
        text.horizontalScale ?? 1,
      );
      if (run.fontSize) textNode.setRangeFontSize(run.start, end, runSize);
      if (run.fillColor) textNode.setRangeFills(run.start, end, [solidPaint(run.fillColor)]);
      if (run.letterSpacing !== undefined) {
        textNode.setRangeLetterSpacing(run.start, end, { unit: 'PIXELS', value: run.letterSpacing });
      }
      const runFont = await tryLoadFont(run.fontFamily, run.fontStyle);
      if (runFont) textNode.setRangeFontName(run.start, end, runFont);
      if (run.underline) textNode.setRangeTextDecoration(run.start, end, 'UNDERLINE');
      if (run.strikethrough) textNode.setRangeTextDecoration(run.start, end, 'STRIKETHROUGH');
    }
  }

  applyEffects(textNode, layer);
  return textNode;
}

async function createTextNode(layer: ImportLayer, options: ImportOptions): Promise<SceneNode | null> {
  if (!layer.text) return null;

  if (options.rasterizeAllText) {
    const rasterNode = await createTextRasterNode(layer);
    if (rasterNode) return rasterNode;
  }

  if (options.rasterizeTextIfFontMissing) {
    const fontsAvailable = await areTextFontsAvailable(layer.text);
    if (!fontsAvailable) {
      warn(
        `Text "${layer.name}" rasterized because font is unavailable in Figma: ${layer.text.fontFamily} ${layer.text.fontStyle}`,
      );
      const rasterNode = await createTextRasterNode(layer);
      if (rasterNode) return rasterNode;
    }
  }

  return createEditableTextNode(layer);
}

function createVectorNode(layer: ImportLayer): VectorNode | null {
  if (!layer.vectorPaths?.length) return null;

  const vector = figma.createVector();
  vector.vectorPaths = layer.vectorPaths.map((path) => ({
    windingRule: path.windingRule,
    data: path.data,
  }));

  vector.resize(Math.max(layer.width, 1), Math.max(layer.height, 1));
  applyFill(vector, layer.fill);
  applyStroke(vector, layer.stroke);
  applyEffects(vector, layer);
  return vector;
}

type ParentNode = BaseNode & ChildrenMixin;

async function createGroupNode(
  layer: ImportLayer,
  parent: ParentNode,
  options: ImportOptions,
  parentX = 0,
  parentY = 0,
): Promise<SceneNode | null> {
  const insertionIndex = parent.children.length;
  const childNodes: SceneNode[] = [];

  if (layer.children?.length) {
    for (const child of layer.children) {
      const childNode = await appendLayerNode(child, parent, options, parentX, parentY);
      if (childNode) childNodes.push(childNode);
    }
  }

  if (!childNodes.length) {
    warn(`Empty group skipped: ${layer.name}`);
    return null;
  }

  const group = figma.group(childNodes, parent, insertionIndex);
  applyCommonProps(group, layer, parentX, parentY, false);
  applyEffects(group, layer);
  return group;
}

async function createArtboardNode(
  layer: ImportLayer,
  parent: ParentNode,
  options: ImportOptions,
  parentX = 0,
  parentY = 0,
): Promise<FrameNode> {
  const frame = figma.createFrame();
  frame.resize(Math.max(layer.width, 1), Math.max(layer.height, 1));
  frame.clipsContent = true;
  frame.fills = [];
  parent.appendChild(frame);
  applyCommonProps(frame, layer, parentX, parentY);
  applyEffects(frame, layer);

  if (layer.children?.length) {
    for (const child of layer.children) {
      await appendLayerNode(child, frame, options, layer.left, layer.top);
    }
  }

  return frame;
}

async function appendLayerNode(
  layer: ImportLayer,
  parent: ParentNode,
  options: ImportOptions,
  parentX = 0,
  parentY = 0,
): Promise<SceneNode | null> {
  if (layer.kind === 'adjustment') {
    warn(`Skipped adjustment layer: ${layer.name}`);
    return null;
  }

  if (layer.kind === 'group') {
    if (layer.isArtboard) {
      return createArtboardNode(layer, parent, options, parentX, parentY);
    }

    return createGroupNode(layer, parent, options, parentX, parentY);
  }

  if (layer.kind === 'text') {
    const textNode = await createTextNode(layer, options);
    if (textNode) {
      parent.appendChild(textNode);
      applyCommonProps(textNode, layer, parentX, parentY);
    }
    return textNode;
  }

  if (layer.kind === 'vector') {
    const vectorNode = createVectorNode(layer);
    if (vectorNode) {
      parent.appendChild(vectorNode);
      applyCommonProps(vectorNode, layer, parentX, parentY);
      return vectorNode;
    }
  }

  if (layer.imageBytes?.length) {
    const imageNode = await createImageNode(layer);
    if (imageNode) {
      parent.appendChild(imageNode);
      applyCommonProps(imageNode, layer, parentX, parentY);
      return imageNode;
    }
  }

  if (layer.kind === 'smartObject') {
    if (layer.imageBytes?.length) {
      const imageNode = await createImageNode(layer);
      if (imageNode) {
        parent.appendChild(imageNode);
        applyCommonProps(imageNode, layer, parentX, parentY);
        return imageNode;
      }
    }
    warn(`Smart object without raster data: ${layer.name}`);
    return null;
  }

  warn(`Empty layer skipped: ${layer.name}`);
  return null;
}

export async function buildFigmaDocument(document: ImportDocument): Promise<{
  roots: SceneNode[];
  layerCount: number;
  warnings: string[];
}> {
  warnings.length = 0;
  const options = resolveOptions(document);
  const hasArtboards = document.layers.some((layer) => layer.isArtboard);
  const roots: SceneNode[] = [];

  let parent: ParentNode = figma.currentPage;
  if (!hasArtboards) {
    const frame = figma.createFrame();
    frame.name = document.name;
    frame.resize(document.width, document.height);
    frame.clipsContent = false;
    frame.fills = [];
    parent.appendChild(frame);
    parent = frame;
    roots.push(frame);
  }

  let layerCount = 0;

  for (const layer of document.layers) {
    const node = await appendLayerNode(layer, parent, options);
    if (node) {
      if (hasArtboards) roots.push(node);
      layerCount += countNodes(layer);
    }
  }

  const selection = roots.length ? roots : [];
  if (selection.length) {
    figma.viewport.scrollAndZoomIntoView(selection);
    figma.currentPage.selection = selection;
  }

  return { roots: selection, layerCount, warnings: [...warnings] };
}

function countNodes(layer: ImportLayer): number {
  let count = 1;
  if (layer.children) {
    for (const child of layer.children) count += countNodes(child);
  }
  return count;
}
