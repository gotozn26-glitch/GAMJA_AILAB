import * as esbuild from 'esbuild';
import * as fs from 'fs';
import * as path from 'path';
import { fileURLToPath } from 'url';

const watch = process.argv.includes('--watch');
const rootDir = path.dirname(fileURLToPath(import.meta.url));

const shared = {
  bundle: true,
  target: 'es2017',
  logLevel: 'info',
  platform: 'browser',
};

async function buildCode() {
  await esbuild.build({
    ...shared,
    entryPoints: ['src/code.ts'],
    outfile: 'code.js',
  });
}

async function buildUiBundle() {
  const result = await esbuild.build({
    ...shared,
    entryPoints: ['src/ui.ts'],
    write: false,
    format: 'iife',
  });

  return result.outputFiles[0].text;
}

function buildUiHtml(uiBundle) {
  const agPsdBundle = fs.readFileSync(
    path.join(rootDir, 'node_modules/ag-psd/dist/bundle.js'),
    'utf8',
  );
  const template = fs.readFileSync(path.join(rootDir, 'ui.template.html'), 'utf8');
  const inlineScript = `${agPsdBundle}\n${uiBundle}`.replace(/<\/script/gi, '<\\/script');
  // Use function replacer: String.replace treats `$'` in replacement as template suffix.
  const html = template.replace('<!-- INLINE_SCRIPT -->', () => inlineScript);
  fs.writeFileSync(path.join(rootDir, 'ui.html'), html);
}

async function buildAll() {
  await buildCode();
  const uiBundle = await buildUiBundle();
  buildUiHtml(uiBundle);
  console.log('Built code.js and ui.html (inline scripts)');
}

if (watch) {
  const codeCtx = await esbuild.context({
    ...shared,
    entryPoints: ['src/code.ts'],
    outfile: 'code.js',
  });
  await codeCtx.watch();

  const uiCtx = await esbuild.context({
    ...shared,
    entryPoints: ['src/ui.ts'],
    write: false,
    format: 'iife',
    plugins: [
      {
        name: 'write-ui-html',
        setup(build) {
          build.onEnd(async (result) => {
            if (result.errors.length) return;
            const uiBundle = result.outputFiles?.[0]?.text;
            if (uiBundle) buildUiHtml(uiBundle);
          });
        },
      },
    ],
  });
  await uiCtx.watch();
  console.log('Watching for changes...');
} else {
  await buildAll();
}
