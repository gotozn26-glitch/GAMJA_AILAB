# PSD/PSB → Figma Importer

Adobe Photoshop `.psd` / `.psb` 파일을 Figma에서 **편집 가능한 레이어**로 가져오는 Figma 플러그인입니다.

## 기능

| Photoshop | Figma |
|-----------|-------|
| 그룹 레이어 | Frame (계층 구조 유지) |
| 텍스트 레이어 | Text (폰트, 크기, 색상, 정렬) |
| 벡터 도형 | Vector (fill, stroke) |
| 래스터 레이어 | Rectangle + Image Fill |
| 스마트 오브젝트 | 래스터 이미지로 import |
| 블렌드 모드 / 불투명도 | Figma blendMode / opacity |
| 드롭 섀도우 / 이너 섀도우 | Figma Effects |

## 설치 및 실행

```bash
npm install
npm run build
```

Figma Desktop에서:

1. **Plugins → Development → Import plugin from manifest...**
2. 이 프로젝트 폴더의 **`manifest.json`** 선택 (루트 폴더)
3. **Plugins → Development → PSD/PSB Importer** 실행
4. PSD/PSB 파일을 드래그하거나 선택

> **중요:** `manifest.json`의 `main`/`ui` 경로에 `/`(슬래시)가 있으면 Figma에서 import가 실패합니다. 반드시 `npm run build` 후 루트의 `manifest.json`을 import하세요.

개발 중에는 `npm run watch`로 자동 빌드할 수 있습니다.

## 아키텍처

```
UI (ui.ts)                    Main (code.ts)
─────────────────             ─────────────────
파일 선택/드래그앤드롭    →    Figma 노드 생성
ag-psd로 PSD 파싱         →    Frame / Text / Vector / Image
직렬화된 레이어 데이터 전송    blendMode, effects 적용
```

- **파싱**: [ag-psd](https://github.com/Agamnentzar/ag-psd) 라이브러리 (브라우저 Canvas 사용)
- **변환**: PSD 레이어 트리 → Figma SceneNode 트리
- **프라이버시**: 모든 처리는 로컬(Figma 플러그인 내부)에서 수행되며 외부 서버로 전송되지 않습니다.

## 제한 사항

- **조정 레이어** (Hue/Saturation, Curves 등): Figma에 대응 기능이 없어 건너뜁니다.
- **픽셀 마스크**: 현재 벡터 마스크 위주 지원 (픽셀 마스크는 향후 추가 예정).
- **폰트**: PSD에 사용된 폰트가 Figma에 없으면 Inter/Roboto/Arial로 대체됩니다.
- **복잡한 레이어 효과** (Bevel, Gradient Overlay 등): 일부만 지원됩니다.
- **텍스트 위치**: Photoshop과 Figma의 텍스트 렌더링 차이로 미세한 위치 차이가 있을 수 있습니다.

## 프로젝트 구조

```
manifest.json       # Figma 플러그인 manifest
ui.html             # 플러그인 UI
src/
  code.ts           # Figma 메인 스레드
  ui.ts             # UI 이벤트 및 파일 처리
  psdParser.ts      # ag-psd → ImportDocument 변환
  figmaBuilder.ts   # ImportDocument → Figma 노드 생성
  figmaMapper.ts    # blendMode, color, font 매핑
  types.ts          # 공유 타입 정의
```

## 라이선스

MIT
