"use strict";
(() => {
  var __defProp = Object.defineProperty;
  var __defProps = Object.defineProperties;
  var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));

  // src/fontParser.ts
  var STYLE_ALIASES = {
    Regular: ["Regular", "Normal", "Book"],
    Medium: ["Medium", "Med"],
    "Semi Bold": ["Semi Bold", "SemiBold", "Demi Bold", "DemiBold"],
    Bold: ["Bold", "Bd"],
    "Extra Bold": ["Extra Bold", "ExtraBold"],
    Light: ["Light", "Lt"],
    "Extra Light": ["Extra Light", "ExtraLight"],
    Thin: ["Thin"],
    Black: ["Black", "Heavy"],
    Italic: ["Italic", "Oblique"],
    "Bold Italic": ["Bold Italic", "BoldItalic"]
  };
  function normalizeFamilyName(family) {
    return family.replace(/\bvariable\b/gi, "").replace(/\bvf\b/gi, "").replace(/\s+/g, " ").trim();
  }
  function buildFontCandidates(family, style) {
    var _a;
    const originalFamily = family.trim();
    const normalizedFamily = normalizeFamilyName(family);
    const styles = (_a = STYLE_ALIASES[style]) != null ? _a : [style, "Regular"];
    const families = Array.from(
      new Set(
        [
          originalFamily,
          normalizedFamily,
          normalizedFamily ? `${normalizedFamily} Variable` : "",
          normalizedFamily ? `${normalizedFamily} VF` : ""
        ].filter(Boolean)
      )
    );
    const candidates = [];
    for (const familyName of families) {
      for (const styleName of styles) {
        candidates.push({ family: familyName, style: styleName });
      }
    }
    for (const familyName of families) {
      candidates.push({ family: familyName, style: "Regular" });
    }
    return candidates;
  }
  function getTextScale(transform) {
    const [a = 1, b = 0, , d = 1] = transform;
    const scaleX = Math.hypot(a, b);
    const scaleY = Math.abs(d) || scaleX;
    if (scaleX <= 0) return scaleY || 1;
    return scaleX;
  }
  function scaledFontSize(fontSize, transform, horizontalScale = 1) {
    return fontSize * getTextScale(transform) * horizontalScale;
  }

  // src/figmaMapper.ts
  var BLEND_MODE_MAP = {
    normal: "NORMAL",
    pass: "PASS_THROUGH",
    dissolve: "NORMAL",
    darken: "DARKEN",
    multiply: "MULTIPLY",
    colorburn: "COLOR_BURN",
    linearburn: "LINEAR_BURN",
    darkercolor: "DARKEN",
    lighten: "LIGHTEN",
    screen: "SCREEN",
    colordodge: "COLOR_DODGE",
    lineardodge: "LINEAR_DODGE",
    lightercolor: "LIGHTEN",
    overlay: "OVERLAY",
    softlight: "SOFT_LIGHT",
    hardlight: "HARD_LIGHT",
    vividlight: "OVERLAY",
    linearlight: "OVERLAY",
    pinlight: "OVERLAY",
    hardmix: "OVERLAY",
    difference: "DIFFERENCE",
    exclusion: "EXCLUSION",
    subtract: "EXCLUSION",
    divide: "EXCLUSION",
    hue: "HUE",
    saturation: "SATURATION",
    color: "COLOR",
    luminosity: "LUMINOSITY"
  };
  function mapBlendMode(psdBlendMode) {
    var _a;
    if (!psdBlendMode) return "NORMAL";
    const key = psdBlendMode.replace(/\s+/g, "").toLowerCase();
    return (_a = BLEND_MODE_MAP[key]) != null ? _a : "NORMAL";
  }
  function psdColorToFigma(color) {
    if (!color) return { r: 0, g: 0, b: 0 };
    return {
      r: color.r / 255,
      g: color.g / 255,
      b: color.b / 255
    };
  }
  function psdOpacityToFigma(opacity) {
    if (opacity === void 0 || opacity === null) return 1;
    return Math.max(0, Math.min(1, opacity));
  }
  function solidPaint(color, opacity = 1) {
    return {
      type: "SOLID",
      color: psdColorToFigma(color),
      opacity: psdOpacityToFigma(opacity)
    };
  }
  function mapTextAlign(justification) {
    switch (justification) {
      case "center":
        return "CENTER";
      case "right":
        return "RIGHT";
      case "justifyAll":
      case "justifyLeft":
      case "justifyCenter":
      case "justifyRight":
        return "JUSTIFIED";
      default:
        return "LEFT";
    }
  }
  function mapTextCase(fontCaps) {
    switch (fontCaps) {
      case 2:
        return "UPPER";
      default:
        return "ORIGINAL";
    }
  }
  var availableFontsPromise = null;
  function normalizeStyleName(style) {
    return style.toLowerCase().replace(/[\s_-]+/g, "");
  }
  async function getAvailableFonts() {
    if (!availableFontsPromise) {
      availableFontsPromise = figma.listAvailableFontsAsync().then((fonts) => fonts.map((font) => font.fontName));
    }
    return availableFontsPromise;
  }
  async function resolveAvailableFont(family, style) {
    const candidates = buildFontCandidates(family, style);
    const availableFonts = await getAvailableFonts();
    for (const candidate of candidates) {
      const match = availableFonts.find(
        (font) => font.family.toLowerCase() === candidate.family.toLowerCase() && font.style.toLowerCase() === candidate.style.toLowerCase()
      );
      if (match) return match;
    }
    for (const candidate of candidates) {
      const candidateFamily = normalizeFamilyName(candidate.family).toLowerCase();
      const candidateStyle = normalizeStyleName(candidate.style);
      const match = availableFonts.find(
        (font) => normalizeFamilyName(font.family).toLowerCase() === candidateFamily && normalizeStyleName(font.style) === candidateStyle
      );
      if (match) return match;
    }
    return null;
  }
  async function tryLoadFont(family, style) {
    const font = await resolveAvailableFont(family, style);
    if (!font) return null;
    try {
      await figma.loadFontAsync(font);
      return font;
    } catch (e) {
      return null;
    }
  }
  async function isExactFontAvailable(family, style) {
    const loaded = await tryLoadFont(family, style);
    if (!loaded) return false;
    return normalizeFamilyName(loaded.family).toLowerCase() === normalizeFamilyName(family).toLowerCase();
  }
  function applyDropShadow(node, shadow) {
    if (!("effects" in node)) return;
    const existing = [...node.effects];
    existing.push({
      type: "DROP_SHADOW",
      color: __spreadProps(__spreadValues({}, psdColorToFigma(shadow.color)), {
        a: psdOpacityToFigma(shadow.opacity)
      }),
      offset: { x: shadow.offsetX, y: shadow.offsetY },
      radius: shadow.blur,
      spread: shadow.spread,
      visible: true,
      blendMode: "NORMAL"
    });
    node.effects = existing;
  }
  function applyInnerShadow(node, shadow) {
    if (!("effects" in node)) return;
    const existing = [...node.effects];
    existing.push({
      type: "INNER_SHADOW",
      color: __spreadProps(__spreadValues({}, psdColorToFigma(shadow.color)), {
        a: psdOpacityToFigma(shadow.opacity)
      }),
      offset: { x: shadow.offsetX, y: shadow.offsetY },
      radius: shadow.blur,
      spread: shadow.spread,
      visible: true,
      blendMode: "NORMAL"
    });
    node.effects = existing;
  }

  // src/figmaBuilder.ts
  var DEFAULT_OPTIONS = {
    rasterizeTextIfFontMissing: true,
    rasterizeAllText: false
  };
  var warnings = [];
  function warn(message) {
    warnings.push(message);
  }
  function resolveOptions(document) {
    return __spreadValues(__spreadValues({}, DEFAULT_OPTIONS), document.options);
  }
  function applyCommonProps(node, layer, parentX = 0, parentY = 0, includePosition = true) {
    if ("name" in node) node.name = layer.name;
    if (includePosition && "x" in node && "y" in node) {
      node.x = layer.left - parentX;
      node.y = layer.top - parentY;
    }
    if ("opacity" in node) node.opacity = psdOpacityToFigma(layer.opacity);
    if ("visible" in node) node.visible = layer.visible;
    if ("blendMode" in node) node.blendMode = mapBlendMode(layer.blendMode);
  }
  function applyEffects(node, layer) {
    var _a, _b;
    if ((_a = layer.effects) == null ? void 0 : _a.dropShadow) {
      for (const shadow of layer.effects.dropShadow) {
        applyDropShadow(node, shadow);
      }
    }
    if ((_b = layer.effects) == null ? void 0 : _b.innerShadow) {
      for (const shadow of layer.effects.innerShadow) {
        applyInnerShadow(node, shadow);
      }
    }
  }
  function applyFill(node, fill) {
    if (!fill || fill.type !== "solid") return;
    node.fills = [solidPaint(fill.color, fill.opacity)];
  }
  function applyStroke(node, stroke) {
    if (!stroke) return;
    node.strokes = [solidPaint(stroke.color, stroke.opacity)];
    node.strokeWeight = stroke.weight;
    if (stroke.align === "inside") node.strokeAlign = "INSIDE";
    else if (stroke.align === "outside") node.strokeAlign = "OUTSIDE";
    else node.strokeAlign = "CENTER";
  }
  async function createImageNodeFromBytes(layer, bytes, width, height, scaleNote, quiet = false) {
    if (!bytes.length) return null;
    const rect = figma.createRectangle();
    rect.resize(Math.max(width, 1), Math.max(height, 1));
    if (scaleNote && !quiet) {
      warn(`${layer.name}: ${scaleNote}`);
    }
    try {
      const image = figma.createImage(new Uint8Array(bytes));
      rect.fills = [
        {
          type: "IMAGE",
          imageHash: image.hash,
          scaleMode: "FILL"
        }
      ];
    } catch (error) {
      const message = error instanceof Error ? error.message : "Invalid image data";
      warn(`Skipped image layer "${layer.name}": ${message}`);
      return null;
    }
    applyEffects(rect, layer);
    return rect;
  }
  async function createImageNode(layer) {
    var _a, _b, _c;
    if (!((_a = layer.imageBytes) == null ? void 0 : _a.length)) return null;
    return createImageNodeFromBytes(
      layer,
      layer.imageBytes,
      (_b = layer.imageWidth) != null ? _b : layer.width,
      (_c = layer.imageHeight) != null ? _c : layer.height,
      layer.imageScaleNote
    );
  }
  async function createTextRasterNode(layer) {
    var _a, _b, _c;
    if (!((_a = layer.textRasterBytes) == null ? void 0 : _a.length)) {
      warn(`Text "${layer.name}": no raster preview in PSD`);
      return null;
    }
    const node = await createImageNodeFromBytes(
      layer,
      layer.textRasterBytes,
      (_b = layer.textRasterWidth) != null ? _b : layer.width,
      (_c = layer.textRasterHeight) != null ? _c : layer.height,
      layer.textRasterScaleNote,
      true
    );
    if (node) {
      warn(`Text "${layer.name}" imported as image (original appearance preserved)`);
    }
    return node;
  }
  function collectTextFonts(text) {
    return [{ family: text.fontFamily, style: text.fontStyle }];
  }
  async function areTextFontsAvailable(text) {
    const [primary] = collectTextFonts(text);
    return isExactFontAvailable(primary.family, primary.style);
  }
  async function createEditableTextNode(layer) {
    var _a, _b, _c, _d;
    if (!layer.text) return null;
    const textNode = figma.createText();
    const text = layer.text;
    const loadedFont = await tryLoadFont(text.fontFamily, text.fontStyle);
    if (loadedFont) {
      textNode.fontName = loadedFont;
    } else {
      warn(`Font not found: ${text.fontFamily} ${text.fontStyle} \u2014 using Inter`);
      await figma.loadFontAsync({ family: "Inter", style: "Regular" });
      textNode.fontName = { family: "Inter", style: "Regular" };
    }
    textNode.characters = text.content;
    textNode.fontSize = scaledFontSize(text.fontSize, text.transform, (_a = text.horizontalScale) != null ? _a : 1);
    textNode.fills = [solidPaint(text.fillColor)];
    if (text.lineHeight) {
      textNode.lineHeight = { unit: "PERCENT", value: text.lineHeight * 100 };
    }
    if (text.letterSpacing !== void 0) {
      textNode.letterSpacing = { unit: "PIXELS", value: text.letterSpacing };
    }
    textNode.textAlignHorizontal = mapTextAlign(text.textAlign);
    textNode.textCase = mapTextCase(text.textCase === "UPPER" ? 2 : 0);
    if (text.textDecoration === "UNDERLINE") textNode.textDecoration = "UNDERLINE";
    if (text.textDecoration === "STRIKETHROUGH") textNode.textDecoration = "STRIKETHROUGH";
    const [a, b] = text.transform;
    if (Math.abs(a - 1) > 1e-3 || Math.abs(b) > 1e-3) {
      const angle = Math.atan2(b, a);
      textNode.rotation = -angle * 180 / Math.PI;
    }
    textNode.textAutoResize = "WIDTH_AND_HEIGHT";
    if ((_b = text.styleRuns) == null ? void 0 : _b.length) {
      for (const run of text.styleRuns) {
        if (run.start >= text.content.length) continue;
        const end = Math.min(run.end, text.content.length);
        const runSize = scaledFontSize(
          (_c = run.fontSize) != null ? _c : text.fontSize,
          text.transform,
          (_d = text.horizontalScale) != null ? _d : 1
        );
        if (run.fontSize) textNode.setRangeFontSize(run.start, end, runSize);
        if (run.fillColor) textNode.setRangeFills(run.start, end, [solidPaint(run.fillColor)]);
        if (run.letterSpacing !== void 0) {
          textNode.setRangeLetterSpacing(run.start, end, { unit: "PIXELS", value: run.letterSpacing });
        }
        const runFont = await tryLoadFont(run.fontFamily, run.fontStyle);
        if (runFont) textNode.setRangeFontName(run.start, end, runFont);
        if (run.underline) textNode.setRangeTextDecoration(run.start, end, "UNDERLINE");
        if (run.strikethrough) textNode.setRangeTextDecoration(run.start, end, "STRIKETHROUGH");
      }
    }
    applyEffects(textNode, layer);
    return textNode;
  }
  async function createTextNode(layer, options) {
    if (!layer.text) return null;
    if (options.rasterizeAllText) {
      const rasterNode = await createTextRasterNode(layer);
      if (rasterNode) return rasterNode;
    }
    if (options.rasterizeTextIfFontMissing) {
      const fontsAvailable = await areTextFontsAvailable(layer.text);
      if (!fontsAvailable) {
        warn(
          `Text "${layer.name}" rasterized because font is unavailable in Figma: ${layer.text.fontFamily} ${layer.text.fontStyle}`
        );
        const rasterNode = await createTextRasterNode(layer);
        if (rasterNode) return rasterNode;
      }
    }
    return createEditableTextNode(layer);
  }
  function createVectorNode(layer) {
    var _a;
    if (!((_a = layer.vectorPaths) == null ? void 0 : _a.length)) return null;
    const vector = figma.createVector();
    vector.vectorPaths = layer.vectorPaths.map((path) => ({
      windingRule: path.windingRule,
      data: path.data
    }));
    vector.resize(Math.max(layer.width, 1), Math.max(layer.height, 1));
    applyFill(vector, layer.fill);
    applyStroke(vector, layer.stroke);
    applyEffects(vector, layer);
    return vector;
  }
  async function createGroupNode(layer, parent, options, parentX = 0, parentY = 0) {
    var _a;
    const insertionIndex = parent.children.length;
    const childNodes = [];
    if ((_a = layer.children) == null ? void 0 : _a.length) {
      for (const child of layer.children) {
        const childNode = await appendLayerNode(child, parent, options, parentX, parentY);
        if (childNode) childNodes.push(childNode);
      }
    }
    if (!childNodes.length) {
      warn(`Empty group skipped: ${layer.name}`);
      return null;
    }
    const group = figma.group(childNodes, parent, insertionIndex);
    applyCommonProps(group, layer, parentX, parentY, false);
    applyEffects(group, layer);
    return group;
  }
  async function createArtboardNode(layer, parent, options, parentX = 0, parentY = 0) {
    var _a;
    const frame = figma.createFrame();
    frame.resize(Math.max(layer.width, 1), Math.max(layer.height, 1));
    frame.clipsContent = true;
    frame.fills = [];
    parent.appendChild(frame);
    applyCommonProps(frame, layer, parentX, parentY);
    applyEffects(frame, layer);
    if ((_a = layer.children) == null ? void 0 : _a.length) {
      for (const child of layer.children) {
        await appendLayerNode(child, frame, options, layer.left, layer.top);
      }
    }
    return frame;
  }
  async function appendLayerNode(layer, parent, options, parentX = 0, parentY = 0) {
    var _a, _b;
    if (layer.kind === "adjustment") {
      warn(`Skipped adjustment layer: ${layer.name}`);
      return null;
    }
    if (layer.kind === "group") {
      if (layer.isArtboard) {
        return createArtboardNode(layer, parent, options, parentX, parentY);
      }
      return createGroupNode(layer, parent, options, parentX, parentY);
    }
    if (layer.kind === "text") {
      const textNode = await createTextNode(layer, options);
      if (textNode) {
        parent.appendChild(textNode);
        applyCommonProps(textNode, layer, parentX, parentY);
      }
      return textNode;
    }
    if (layer.kind === "vector") {
      const vectorNode = createVectorNode(layer);
      if (vectorNode) {
        parent.appendChild(vectorNode);
        applyCommonProps(vectorNode, layer, parentX, parentY);
        return vectorNode;
      }
    }
    if ((_a = layer.imageBytes) == null ? void 0 : _a.length) {
      const imageNode = await createImageNode(layer);
      if (imageNode) {
        parent.appendChild(imageNode);
        applyCommonProps(imageNode, layer, parentX, parentY);
        return imageNode;
      }
    }
    if (layer.kind === "smartObject") {
      if ((_b = layer.imageBytes) == null ? void 0 : _b.length) {
        const imageNode = await createImageNode(layer);
        if (imageNode) {
          parent.appendChild(imageNode);
          applyCommonProps(imageNode, layer, parentX, parentY);
          return imageNode;
        }
      }
      warn(`Smart object without raster data: ${layer.name}`);
      return null;
    }
    warn(`Empty layer skipped: ${layer.name}`);
    return null;
  }
  async function buildFigmaDocument(document) {
    warnings.length = 0;
    const options = resolveOptions(document);
    const hasArtboards = document.layers.some((layer) => layer.isArtboard);
    const roots = [];
    let parent = figma.currentPage;
    if (!hasArtboards) {
      const frame = figma.createFrame();
      frame.name = document.name;
      frame.resize(document.width, document.height);
      frame.clipsContent = false;
      frame.fills = [];
      parent.appendChild(frame);
      parent = frame;
      roots.push(frame);
    }
    let layerCount = 0;
    for (const layer of document.layers) {
      const node = await appendLayerNode(layer, parent, options);
      if (node) {
        if (hasArtboards) roots.push(node);
        layerCount += countNodes(layer);
      }
    }
    const selection = roots.length ? roots : [];
    if (selection.length) {
      figma.viewport.scrollAndZoomIntoView(selection);
      figma.currentPage.selection = selection;
    }
    return { roots: selection, layerCount, warnings: [...warnings] };
  }
  function countNodes(layer) {
    let count = 1;
    if (layer.children) {
      for (const child of layer.children) count += countNodes(child);
    }
    return count;
  }

  // src/code.ts
  figma.showUI(__html__, { width: 420, height: 580, themeColors: true });
  figma.ui.onmessage = async (msg) => {
    if (msg.type === "cancel") {
      figma.closePlugin();
      return;
    }
    if (msg.type === "import-document") {
      try {
        postToUi({ type: "import-started" });
        const result = await buildFigmaDocument(msg.document);
        postToUi({
          type: "import-done",
          layerCount: result.layerCount,
          warnings: result.warnings
        });
        figma.notify(`Imported ${result.layerCount} layers from ${msg.document.name}`);
      } catch (error) {
        const message = error instanceof Error ? error.message : "Unknown import error";
        postToUi({ type: "import-failed", message });
        figma.notify(`Import failed: ${message}`, { error: true });
      }
      return;
    }
    if (msg.type === "import-complete") {
      return;
    }
  };
  function postToUi(message) {
    figma.ui.postMessage(message);
  }
})();
